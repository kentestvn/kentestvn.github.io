from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus, urljoin
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from concurrent.futures import ThreadPoolExecutor
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pathlib import Path
from html import unescape
from pickle import load, dump
import re, sys, urlquick, xbmcgui, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
opimg = RESOURCES + 'op.png'
kkimg = RESOURCES + 'kk.png'
ncimg = RESOURCES + 'nc.png'
rfimg = RESOURCES + 'rf.png'
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/605.1.15 EdgA/134.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
o1 = 'https://ophim1.com'
uop = f'{o1}/v1/api'
op = 'https://ophim.live'
ukk = 'https://phimapi.com'
kk = 'https://kkphim.com'
unc = 'https://phim.nguonc.com'
rf = 'https://api.rophim.me/v1/'
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def limit_files_in_directory(directory):
    files = sorted(Path(directory).glob('*'), key=os.path.getmtime)
    while len(files) > 5:
        oldest_file = files.pop(0)
        try:
            oldest_file.unlink()
        except Exception as e:
            pass
def process_m3u8(url):
    response = getlink(url, url, 300)
    parsed_url = urlparse(url.strip())
    domain = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path.rsplit('/', 1)[0]}/"
    lines = response.text.splitlines()
    cleaned_lines = []
    discontinuity_blocks = []
    current_block = []
    in_discontinuity = False
    for line in lines:
        if line.startswith("#EXTM3U"):
            cleaned_lines.append(line)
        elif line.startswith("#EXT-X-STREAM-INF"):
            next_line = lines[lines.index(line) + 1].strip()
            new_url = urljoin(url, next_line)
            return process_m3u8(new_url)
        elif line.startswith("#EXT-X-DISCONTINUITY"):
            if in_discontinuity:
                discontinuity_blocks.append(current_block)
            current_block = [line]
            in_discontinuity = True
        elif in_discontinuity:
            if line.endswith(".ts") and not line.startswith("http"):
                line = urljoin(domain, line)
            current_block.append(line)
        else:
            if line.endswith(".ts") and not line.startswith("http"):
                line = urljoin(domain, line)
            cleaned_lines.append(line)
    if current_block:
        discontinuity_blocks.append(current_block)
    def block_duration(block):
        return sum(float(re.search(r"#EXTINF:([\d\.]+)", l).group(1)) for l in block if l.startswith("#EXTINF"))
    if 0 < len(discontinuity_blocks) < 4:
        del discontinuity_blocks[0:len(discontinuity_blocks) - 1]
    valid_blocks = []
    for block in discontinuity_blocks:
        if block_duration(block) >= 20:
            valid_blocks.append(block)
        else:
            valid_blocks.append([l for l in block if not l.startswith("#EXTINF") and not l.endswith(".ts")])
    for block in valid_blocks:
        cleaned_lines.extend(block)
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path_parts = parsed_url.path.strip('/').split('/')
    name = '_'.join(path_parts)
    path = os.path.join(addon_data_dir, name)
    with open(path, 'w+') as f:
        for line in cleaned_lines:
            f.write(f'{line}\n')
    limit_files_in_directory(addon_data_dir)
    return path
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def safe_join(value):
    if isinstance(value, list):
        return ','.join(value)
    return value
def convert_image_url(path):
    filename = path.split('/')[-1]
    return f"https://static.nutscdn.com/vimg/300-0/{filename}"
def find():
    addDir('Tìm phim', searchimg, 'Tìm phim', 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, 'tim_apii', key=m, p=1)
    endOfDirectory(HANDLE)
def get_info_ophim(x):
    r = getlink(f'{uop}/phim/{x}','https://ophim1.com/',-1)
    try:
        kq = r.json()['data']
        try:
            img = kq['seoOnPage']['seoSchema']['image']
        except:
            img = opimg
        try:
            ten = kq['item']['name']
        except:
            pass
        try:
            mota = unescape(re.sub('<.*?>', '', kq['item']['content']))
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def get_info_kkphim(x):
    r = getlink(f'{ukk}/phim/{x}',ukk,-1)
    try:
        kq = r.json()['movie']
        try:
            img = kq['poster_url']
        except:
            img = kkimg
        try:
            ten = kq['name']
        except:
            pass
        try:
            mota = unescape(kq['content'])
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def get_info_nguonc(x):
    r = getlink(f'{unc}/api/film/{x}', unc,-1)
    try:
        kq = r.json()['movie']
        try:
            img = kq['thumb_url']
        except:
            img = ncimg
        try:
            ten = kq['name']
        except:
            pass
        try:
            mota = re.sub('<.*?>', '', kq['description'])
        except:
            mota = ten
        return (ten, img, mota)
    except:
        return None
def op_process_url(url):
    try:
        data = get_info_ophim(url)
        return url, data
    except:
        return url, None
def kk_process_url(url):
    try:
        data = get_info_kkphim(url)
        return url, data
    except:
        return url, None
def nc_process_url(url):
    try:
        data = get_info_nguonc(url)
        return url, data
    except:
        return url, None
def get_op(search_query, next_page):
    r = getlink(f'{uop}/tim-kiem?keyword={search_query}&page={next_page}', uop, 1000)
    return ((k['name'], k['thumb_url'], k['slug'], r.json()['data']['APP_DOMAIN_CDN_IMAGE']) for k in r.json()['data']['items'])
def get_kk(search_query, next_page):
    r = getlink(f'{ukk}/v1/api/tim-kiem?keyword={search_query}&page={next_page}', ukk, 1000)
    return ((k['name'], k['poster_url'], k['slug'], r.json()['data']['APP_DOMAIN_CDN_IMAGE']) for k in r.json()['data']['items'])
def get_nc(search_query, next_page):
    r = getlink(f'{unc}/api/films/search?keyword={search_query}&page={next_page}', unc, 1000)
    return ((k['name'], k['thumb_url'], k['slug']) for k in r.json()['items'])
def timkiem(query, next_page):
    sr = quote_plus(query)
    processed_ids = set()
    with ThreadPoolExecutor(3) as ex:
        f1 = ex.submit(get_op, sr, next_page)
        f2 = ex.submit(get_kk, sr, next_page)
        f3 = ex.submit(get_nc, sr, next_page)
    try:
        for k in f1.result():
            if k[2] not in processed_ids:
                addDir(k[0], f'{k[3]}/uploads/movies/{k[1]}', k[0], 'id_film', id=k[2])
                processed_ids.add(k[2])
    except:
        pass
    try:
        for l in f2.result():
            if l[2] not in processed_ids:
                addDir(l[0], f'{l[3]}/{l[1]}', l[0], 'id_film', id=l[2])
                processed_ids.add(l[2])
    except:
        pass
    try:
        for m in f3.result():
            if m[2] not in processed_ids:
                addDir(m[0], m[1], m[0], 'id_film', id=m[2])
                processed_ids.add(m[2])
    except:
        pass
    tiep = str(next_page + 1)
    addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'tim_apii', key=query, p=tiep)
    endOfDirectory(HANDLE)
def op_phanloai(phanloai, trang):
    u = f'{o1}/{phanloai}'
    resp = getlink(u, u, 1000)
    ri = resp.json()
    for k in ri:
        ten = k['name']
        addDir(ten, ICON, ten, 'ds_op', url = f"{uop}/{phanloai}/{k['slug']}", p=trang)
    endOfDirectory(HANDLE)
def kk_phanloai(phanloai, trang):
    u = f'{ukk}/{phanloai}'
    resp = getlink(u, u, 1000)
    ri = resp.json()
    for k in ri:
        ten = k['name']
        addDir(ten, ICON, ten, 'ds_kk', url = f"{ukk}/v1/api/{phanloai}/{k['slug']}?limit=30", p=trang)
    endOfDirectory(HANDLE)
def ds_op(match, next_page):
    n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    resp = getlink(n, n, 1000)
    ri = resp.json()['data']['items']
    urls = [k['slug'] for k in ri]
    length = len(urls)
    if length>0:
        with ThreadPoolExecutor(length) as ex:
            results = ex.map(op_process_url, urls)
        for (l, data) in results:
            if data is not None:
                addDir(data[0], data[1], data[2], 'id_film', id = l)
        tiep = str(next_page + 1)
        addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_op', url = match, p=tiep)
    endOfDirectory(HANDLE)
def ds_kk(match, next_page):
    n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    resp = getlink(n, n, 1000)
    ri = resp.json()['data']['items'] if (resp is not None) and ('"data"' in resp.text) else resp.json()['items']
    urls = [k['slug'] for k in ri]
    length = len(urls)
    if length>0:
        with ThreadPoolExecutor(length) as ex:
            results = ex.map(kk_process_url, urls)
        for (l, data) in results:
            if data is not None:
                addDir(data[0], data[1], data[2], 'id_film', id=l)
        if (next_page < resp.json().get('data', {}).get('params', {}).get('pagination', {}).get('totalItemsPerPage', float('inf')) or
            next_page < resp.json().get('items', {}).get('pagination', {}).get('totalItemsPerPage', float('inf'))):
            tiep = str(next_page + 1)
            addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_kk', url = match, p=tiep)
    endOfDirectory(HANDLE)
def ds_nc(match, next_page):
    n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
    resp = getlink(n, n, 1000)
    urls = [k['slug'] for k in resp.json()['items']]
    length = len(urls)
    if length>0:
        with ThreadPoolExecutor(length) as ex:
            results = ex.map(nc_process_url, urls)
        for (l, data) in results:
            if data is not None:
                addDir(data[0], data[1], data[2], 'id_film', id=l)
        if next_page < resp.json()['paginate']['total_page']:
            tiep = str(next_page + 1)
            addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'ds_nc', url = match, p=tiep)
    endOfDirectory(HANDLE)
def id_op(idk):
    try:
        t = f'{uop}/phim/{idk}'
        resp = getlink(t, t, 1000)
        kq = resp.json()
        ke = kq['data']['item']['episodes']
        title = kq['data']['item']['name']
        mota = unescape(re.sub('<.*?>', '', kq['data']['item']['content']))
        anh = kq['data']['seoOnPage']['seoSchema']['image']
        return ((k1['server_name'], k2['name'], k2['link_m3u8'], title, anh, mota) for k1 in ke for k2 in k1['server_data'] if k2['link_m3u8'])
    except:
        return False
def id_kk(idk):
    try:
        t = f'{ukk}/phim/{idk}'
        resp = getlink(t, t, 1000)
        kq = resp.json()
        ke = kq['episodes']
        title = kq['movie']['name']
        mota = unescape(kq['movie']['content'])
        anh = kq['movie']['poster_url']
        return ((k1['server_name'], k2['name'], k2['link_m3u8'], title, anh, mota) for k1 in ke for k2 in k1['server_data'] if k2['link_m3u8'])
    except:
        return False
def id_nc(idk):
    try:
        t = f'{unc}/api/film/{idk}'
        resp = getlink(t, t, 1000)
        kq = resp.json()
        ke = kq['movie']['episodes']
        title = kq['movie']['name']
        mota = re.sub('<.*?>', '', kq['movie']['description'])
        anh = kq['movie']['thumb_url']
        return ((k1['server_name'], k2['name'], k2['embed'], title, anh, mota) for k1 in ke for k2 in k1['items'] if k2['embed'])
    except:
        return False
def play_vn(link):
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'embed.php' in link:
        enlink = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
        hdr = f'verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(enlink)}'
        linkplay = enlink.replace('embed.php', 'get.php')
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = process_m3u8(link)
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', 'timkiem')
    addDir('Nổi bật', rfimg, 'Nổi bật', 'rf_hot')
    u = f'{rf}collection/list?page=1&limit=100'
    response = getlink(u, rf, -1).json()['result']['collections']
    for k in response:
        name = k['name']
        if 'filter' not in k or k['type'] == 1:
            idp = k['_id']
            addDir(name, rfimg, name, 'rophim_index2', idp = idp)
        else:
            filterx = k['filter']
            params = {
                'countries': safe_join(filterx.get('country_code', '')),
                'genres': safe_join(filterx.get('genre_ids', '')),
                'years': safe_join(filterx.get('years', '')),
                'type': safe_join(filterx.get('type', '')),
                'status': safe_join(filterx.get('status', '')),
                'exclude_status': safe_join(filterx.get('exclude_status', '')),
                'versions': safe_join(filterx.get('versions', '')),
                'rating': safe_join(filterx.get('rating', '')),
                'networks': safe_join(filterx.get('networks', '')),
                'productions': safe_join(filterx.get('productions', '')),
                'sort': safe_join(filterx.get('sort_by', '')),
                'keyword': ''
            }
            url = f"{rf}movie/filterV2?" + '&'.join(f"{k}={v.replace(' ', '%20')}" for k, v in params.items())
            addDir(name, rfimg, name, 'rophim_index', url = url, p = 1)
    addDir('OPHIM', opimg, 'OPHIM', 'op_index')
    addDir('KKPHIM', kkimg, 'KKPHIM', 'kk_index')
    addDir('NGUONC', ncimg, 'NGUONC', 'nc_index')
    endOfDirectory(HANDLE)
def rf_hot():
    u = f'{rf}movie/hot'
    r = getlink(u, rf, -1).json()['result']
    for k in r:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def rophim_index(url, p):
    u = f'{url}&page={p}'
    r = getlink(u, rf, -1).json()['result']
    page_count = r['page_count']
    for k in r['items']:
        name = k['title']
        info = k['overview']
        img = convert_image_url(k['images']['posters'][-1]['path'])
        slug = k['slug']
        addDir(name, img, info, 'id_film', id=slug)
    if page_count > 1:
        tiep = str(p + 1)
        addDir(f'Trang {tiep}', nextimg, f'Trang {tiep}', 'rophim_index', url = url, p = tiep)
    endOfDirectory(HANDLE)
def rophim_index2(idp):
    u = f'{rf}collection/list?page=1&limit=100'
    r = getlink(u, rf, -1).json()['result']['collections']
    for k in r:
        if k['_id'] == idp:
            for m in k['movies']:
                name = m['title']
                info = m['overview']
                img = convert_image_url(m['images']['posters'][-1]['path'])
                slug = m['slug']
                addDir(name, img, info, 'id_film', id=slug)
    endOfDirectory(HANDLE)
def op_index():
    T = {'Thể loại': 'op_tl',
    'Quốc gia': 'op_qg'}
    dulieu = {
    'Phim mới': f'{uop}/danh-sach/phim-moi-cap-nhat',
    'Phim bộ': f'{uop}/danh-sach/phim-bo',
    'Phim bộ hoàn thành': f'{uop}/danh-sach/phim-bo-hoan-thanh',
    'Phim lẻ': f'{uop}/danh-sach/phim-le',
    'TV shows': f'{uop}/danh-sach/tv-shows',
    'Hoạt hình': f'{uop}/danh-sach/hoat-hinh',
    'Phim thuyết minh': f'{uop}/danh-sach/phim-thuyet-minh',
    'Phim lồng tiếng': f'{uop}/danh-sach/phim-long-tieng',
    'Phim phụ đề': f'{uop}/danh-sach/phim-vietsub',
    'Phim phụ đề độc quyền': f'{uop}/danh-sach/subteam'
    }
    for b in T:
        addDir(b, opimg, b, T[b])
    for k in dulieu:
        addDir(k, opimg, k, 'ds_op', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def kk_index():
    T = {'Thể loại': 'kk_tl',
    'Quốc gia': 'kk_qg'}
    dulieu = {
    'Phim mới': f'{ukk}/danh-sach/phim-moi-cap-nhat-v2?limit=30',
    'Phim lẻ': f'{ukk}/v1/api/danh-sach/phim-le?limit=30',
    'Phim bộ': f'{ukk}/v1/api/danh-sach/phim-bo?limit=30',
    'Hoạt hình': f'{ukk}/v1/api/danh-sach/hoat-hinh?limit=30',
    'TV Shows': f'{ukk}/v1/api/danh-sach/tv-shows?limit=30'
    }
    for b in T:
        addDir(b, kkimg, b, T[b])
    for k in dulieu:
        addDir(k, kkimg, k, 'ds_kk', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def nc_index():
    T = {'Thể loại': 'nc_tl',
    'Quốc gia': 'nc_qg',
    'Năm': 'nc_nam'}
    dulieu = {
    'Phim mới': f'{unc}/api/films/phim-moi-cap-nhat',
    'Phim đang chiếu': f'{unc}/api/films/danh-sach/phim-dang-chieu',
    'Phim lẻ': f'{unc}/api/films/danh-sach/phim-le',
    'Phim bộ': f'{unc}/api/films/danh-sach/phim-bo',
    'Hoạt hình': f'{unc}/api/films/the-loai/hoat-hinh',
    'TV Shows': f'{unc}/api/films/danh-sach/tv-shows'
    }
    for b in T:
        addDir(b, ncimg, b, T[b])
    for k in dulieu:
        addDir(k, ncimg, k, 'ds_nc', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def nc_tl():
    dulieu = {
    'Hành Động': f'{unc}/api/films/the-loai/hanh-dong',
    'Phiêu Lưu': f'{unc}/api/films/the-loai/phieu-luu',
    'Hoạt Hình': f'{unc}/api/films/the-loai/hoat-hinh',
    'Hài': f'{unc}/api/films/the-loai/phim-hai',
    'Hình Sự': f'{unc}/api/films/the-loai/hinh-su',
    'Tài Liệu': f'{unc}/api/films/the-loai/tai-lieu',
    'Chính Kịch': f'{unc}/api/films/the-loai/chinh-kich',
    'Gia Đình': f'{unc}/api/films/the-loai/gia-dinh',
    'Giả Tượng': f'{unc}/api/films/the-loai/gia-tuong',
    'Lịch Sử': f'{unc}/api/films/the-loai/lich-su',
    'Kinh Dị': f'{unc}/api/films/the-loai/kinh-di',
    'Nhạc': f'{unc}/api/films/films/the-loai/phim-nhac',
    'Bí Ẩn': f'{unc}/api/films/the-loai/bi-an',
    'Lãng Mạn': f'{unc}/api/films/the-loai/lang-man',
    'Khoa Học Viễn Tưởng': f'{unc}/api/films/the-loai/khoa-hoc-vien-tuong',
    'Gây Cấn': f'{unc}/api/films/the-loai/gay-can',
    'Chiến Tranh': f'{unc}/api/films/the-loai/chien-tranh',
    'Tâm Lý': f'{unc}/api/films/the-loai/tam-ly',
    'Tình Cảm': f'{unc}/api/films/the-loai/tinh-cam',
    'Cổ Trang': f'{unc}/api/films/the-loai/co-trang',
    'Miền Tây': f'{unc}/api/films/the-loai/mien-tay',
    'Phim 18+': f'{unc}/api/films/the-loai/phim-18'
    }
    for k in dulieu:
        addDir(k, ncimg, k, 'ds_nc', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def nc_qg():
    dulieu = {
    'Âu Mỹ': f'{unc}/api/films/quoc-gia/au-my',
    'Anh': f'{unc}/api/films/quoc-gia/anh',
    'Trung Quốc': f'{unc}/api/films/quoc-gia/trung-quoc',
    'Indonesia': f'{unc}/api/films/quoc-gia/indonesia',
    'Việt Nam': f'{unc}/api/films/quoc-gia/viet-nam',
    'Pháp': f'{unc}/api/films/quoc-gia/phap',
    'Hồng Kông': f'{unc}/api/films/quoc-gia/hong-kong',
    'Hàn Quốc': f'{unc}/api/films/quoc-gia/han-quoc',
    'Nhật Bản': f'{unc}/api/films/quoc-gia/nhat-ban',
    'Thái Lan': f'{unc}/api/films/quoc-gia/thai-lan',
    'Đài Loan': f'{unc}/api/films/quoc-gia/dai-loan',
    'Nga': f'{unc}/api/films/quoc-gia/nga',
    'Hà Lan': f'{unc}/api/films/quoc-gia/ha-lan',
    'Philippines': f'{unc}/api/films/films/quoc-gia/philippines',
    'Ấn Độ': f'{unc}/api/films/quoc-gia/an-do',
    'Quốc gia khác': f'{unc}/api/films/quoc-gia/quoc-gia-khac'
    }
    for k in dulieu:
        addDir(k, ncimg, k, 'ds_nc', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def nc_nam():
    dulieu = {
    '2004': f'{unc}/api/films/nam-phat-hanh/2004',
    '2005': f'{unc}/api/films/nam-phat-hanh/2005',
    '2006': f'{unc}/api/films/nam-phat-hanh/2006',
    '2007': f'{unc}/api/films/nam-phat-hanh/2007',
    '2008': f'{unc}/api/films/nam-phat-hanh/2008',
    '2009': f'{unc}/api/films/nam-phat-hanh/2009',
    '2010': f'{unc}/api/films/nam-phat-hanh/2010',
    '2011': f'{unc}/api/films/nam-phat-hanh/2011',
    '2012': f'{unc}/api/films/nam-phat-hanh/2012',
    '2013': f'{unc}/api/films/nam-phat-hanh/2013',
    '2014': f'{unc}/api/films/nam-phat-hanh/2014',
    '2015': f'{unc}/api/films/nam-phat-hanh/2015',
    '2016': f'{unc}/api/films/nam-phat-hanh/2016',
    '2017': f'{unc}/api/films/nam-phat-hanh/2017',
    '2018': f'{unc}/api/films/nam-phat-hanh/2018',
    '2019': f'{unc}/api/films/nam-phat-hanh/2019',
    '2020': f'{unc}/api/films/nam-phat-hanh/2020',
    '2021': f'{unc}/api/films/nam-phat-hanh/2021',
    '2022': f'{unc}/api/films/nam-phat-hanh/2022',
    '2023': f'{unc}/api/films/nam-phat-hanh/2023',
    '2024': f'{unc}/api/films/nam-phat-hanh/2024',
    }
    for k in dulieu:
        addDir(k, ncimg, k, 'ds_nc', url = dulieu[k], p=1)
    endOfDirectory(HANDLE)
def id_film(idk):
    with ThreadPoolExecutor(3) as ex:
        futures = {
            'OP': ex.submit(id_op, idk),
            'KK': ex.submit(id_kk, idk),
            'NC': ex.submit(id_nc, idk)
        }
    for label, future in futures.items():
        result = future.result()
        if result:
            for item in result:
                ep = f'Tập {item[1]}' if not item[1].startswith('Tập') else item[1]
                addDir(f"{item[3]} | {label} {item[0]} | {ep}", item[4], item[5], 'play_vn', url=item[2], is_folder=False)
    endOfDirectory(HANDLE)
def search():
    query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        search_history_save(query)
        timkiem(query, 1)
    else:
        find()
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'op_index': op_index,
        'kk_index': kk_index,
        'nc_index': nc_index,
        'rf_hot': rf_hot,
        'op_tl': partial(op_phanloai, 'the-loai', 1),
        'op_qg': partial(op_phanloai, 'quoc-gia', 1),
        'kk_tl': partial(kk_phanloai, 'the-loai', 1),
        'kk_qg': partial(kk_phanloai, 'quoc-gia', 1),
        'nc_tl': nc_tl,
        'nc_qg': nc_qg,
        'nc_nam': nc_nam,
        'ds_op': partial(ds_op, params.get('url'), int(params.get('p', 0))),
        'ds_kk': partial(ds_kk, params.get('url'), int(params.get('p', 0))),
        'ds_nc': partial(ds_nc, params.get('url'), int(params.get('p', 0))),
        'rophim_index': partial(rophim_index, params.get('url'), int(params.get('p', 0))),
        'id_film': partial(id_film, params.get('id')),
        'rophim_index2': partial(rophim_index2, params.get('idp')),
        'search': search,
        'timkiem': find,
        'tim_apii': partial(timkiem, params.get('key'), int(params.get('p', 0))),
        'play_vn': partial(play_vn, params.get('url')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass