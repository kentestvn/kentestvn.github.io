from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from urllib.parse import urlencode, parse_qsl, quote_plus, urlparse, unquote
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection
from xbmcvfs import translatePath
from xbmc import executebuiltin
from json import loads, dumps
from pickle import load, dump
from requests import Session
from xbmcaddon import Addon
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro Build/AP4A.251212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
ufn = 'https://thuvienhd.xyz'
userfs = 'FshareiOSApp-saCP7ssw2u7w'
keyfs = 'MkywVt2UBRHcJXUUcfsZ7XXzBSJV3dwE'
tmdbAPI='https://api.themoviedb.org/3'
apimdb='b030404650f279792a8d3287232358e3'
apiKey = f'{apimdb}&language=vi-VN'
append = 'alternative_titles,credits,external_ids,keywords,videos,recommendations'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
thaythe = {'|':'$','@':'', '*': ''}
def addDir(title=None, img=None, plot=None, size=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if size is not None:
        list_item.setInfo(type='Video', infoLabels={'size': size})
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def urlfix(url):
    cleaned_location = '%20'.join(url.strip().split())
    return re.sub(r':(\/+)', r'://', cleaned_location)
def fu(url):
    parsed_url = urlparse(url)
    conn = HTTPConnection(parsed_url.netloc)
    conn.request('HEAD', parsed_url.path)
    response = conn.getresponse().getheader('Location')
    if response is not None:
        return urlfix(response)
    else:
        with Session() as s:
            try:
                r = s.get(url, timeout=30, allow_redirects=False)
            except:
                r = s.get(url, timeout=30, verify=False, allow_redirects=False)
        try:
            return urlfix(r.headers['Location'])
        except:
            return urlfix(r.url)
def get_tkfs1(search_query):
    u = f'{ufn}/?feed=fsharejson&search={search_query}'
    r1 = getlink(u, ufn, 1000)
    r2 = getlink(f'{ufn}/?feed=fsharejson&search=', ufn, 1000)
    rj = loads(re.sub(r'<(.*?)\n','', r1.text))
    for t in rj:
        if r1.content != r2.content:
            img = t['image']
            name = t['title'].replace('&&','-')
            addDir(name, t['image'], name, None, 'thuvienhd_link', idk = t['id'], info = name, ground = img)
def get_tkfs2(search_query):
    urlx = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
    headers = {
        'user-agent': UA,
        'referer': 'https://timfshare.com/',
        'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'
    }
    response = urlquick.post(urlx, timeout=30, max_age=1000, headers=headers)
    data = response.json().get('data', [])
    for item in data:
        name = item['name']
        url = item['url']
        size = item['size']
        if 'folder' in url:
            addDir(name, ICON, name, None, 'index_fs', link = url, p=1)
        else:
            addDir(name, ICON, name, size, 'play_fs', link = url, tenphim = name, is_folder=False)
def getrow(row):
    return row['v'] if (row is not None) and (row['v'] is not None) else ''
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
    return os.path.exists(get_file_path(filename))
def remove_file(filename):
    if has_file_path(filename):
        os.remove(get_file_path(filename))
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def convert_to_kb(size_str):
    size_str = size_str.strip().lower()
    if "gb" in size_str:
        size_in_gb = float(size_str.replace("gb", "").strip())
        return int(size_in_gb * 1024 * 1024 * 1024)
    elif "mb" in size_str:
        size_in_mb = float(size_str.replace("mb", "").strip())
        return int(size_in_mb * 1024 * 1024)
    elif "kb" in size_str:
        size_in_kb = float(size_str.replace("kb", "").strip())
        return int(size_in_kb * 1024)
    else:
        return None
def replace_all(dict, str):
    pattern = re.compile('|'.join(re.escape(key) for key in dict.keys()))
    return pattern.sub(lambda match: dict[match.group()], str)
def userpassfs():
    username = Addon().getSetting('username')
    password = Addon().getSetting('password')
    if username and password:
        payload = {'user_email':username,'password':password,'app_key':keyfs}
        head = {'user-agent':userfs, 'content-type': 'application/json; charset=utf-8'}
        try:
            response = urlquick.post('https://api.fshare.vn/api/user/login',data=dumps(payload),headers=head,timeout=30,max_age=7200)
            headerfsvn = {'user-agent':userfs, 'cookie' : f"session_id={response.json()['session_id']}"}
            with Session() as s:
                r = s.get('https://api.fshare.vn/api/user/get', timeout=30, headers=headerfsvn)
            if r.status_code == 200:
                return (response.json()['token'], response.json()['session_id'])
            else:
                urlquick.cache_cleanup(-1)
                remove_file('.urlquick.slite3')
                userpassfs()
        except:
            urlquick.cache_cleanup(-1)
            remove_file('.urlquick.slite3')
            executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Đăng nhập thất bại', 5000, ICON))
            sys.exit()
    else:
        executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Vui lòng nhập tài khoản Fshare trong cài đặt của VN Media', 5000, ICON))
        sys.exit()
def listvmf_gcs(url):
    resp = getlink(url, url, -1)
    ri = resp.iter_lines(decode_unicode=True)
    tach = (ll.rstrip() for ll in ri if ll.strip())
    for link in tach:
        create_listitem_from_link(link)
def set_item_callbacks(link, name, info, anh, sub):
    if 'fshare.vn/folder' in link:
        return addDir(name, anh, info, None, 'index_fs', link = link, p=1)
    elif 'fshare.vn/file' in link:
        return addDir(name, anh, info, None, 'play_fs', link = link, tenphim = name, is_folder=False)
    elif 'docs.google.com' in link:
        return addDir(name, anh, info, None, 'listgg_gcs', link = link)
    elif 'VMF' in link:
        return addDir(name, anh, info, None, 'listvmf_gcs', link = link.replace('VMF-', ''))
    elif 'timvmf' in link:
        return addDir(name, anh, info, None, 'timvmf', link = link.replace('timvmf-', ''))
    else:
        return addDir(name, anh, info, None, 'play_vnm', link = link, tenphim = name, sub=sub, is_folder=False)
def create_listitem_from_link(link):
    tachhat = link.split('$')
    ltach = len(tachhat)
    if ltach > 1:
        kenh = tachhat[1]
        tenm = tachhat[0]
        imgfs = tachhat[3] if ltach > 3 else ICON
        sub = tachhat[2] if ltach > 2 else None
        if ltach > 4:
            info = tachhat[4]
        else:
            info = tenm
        return set_item_callbacks(kenh, tenm, info, imgfs, sub)
def listgg_gcs(x):
    if 'gid' in x:
        timid = re.findall(r'/d/(.*?)/.*?gid=(\d+)', x)
        sid = timid[0][0]
        gid = timid[0][1]
    else:
        sid = re.findall(r'/d/(.*?)/', x)[0]
        gid = '0'
    url = f'https://docs.google.com/spreadsheets/d/{sid}/gviz/tq?gid={gid}&headers=1'
    resp = getlink(url, url, 600)
    noi = re.search(r'\{.*\}', resp.text)[0]
    m = loads(noi)
    cols = m['table']['cols']
    rows = m['table']['rows']
    kenh = cols[1]['label']
    if 'http' in kenh:
        lcols = len(cols)
        tenm = cols[0]['label']
        imgfs = cols[2]['label'] if lcols > 2 else ICON
        if lcols > 3:
            info = f"{cols[3]['label']}"
        else:
            info = f'{tenm}\nNguồn: {u}'
        set_item_callbacks(kenh, tenm, info, imgfs, None)
    for cow in cols:
        p = cow['label']
        if '|http' in p:
            create_listitem_from_link(replace_all(thaythe, p))
    for row in rows:
        k = getrow(row['c'][0])
        if '|http' in k:
            create_listitem_from_link(replace_all(thaythe, k))
        elif 'http' in getrow(row['c'][1]):
            lrow = len(row['c'])
            kenh = getrow(row['c'][1])
            imgfs = getrow(row['c'][2]) if lrow > 2 else ICON
            if lrow > 3:
                info = getrow(row['c'][3])
            else:
                info = f'{k}\nNguồn: {u}'
            set_item_callbacks(kenh, k, info, imgfs, None)
def index_gcs():
    u = Addon().getSetting('TextURL')
    if u:
        x = fu(u)
        if 'docs.google.com' in x:
            listgg_gcs(x)
        else:
            listvmf_gcs(u)
        endOfDirectory(HANDLE)
    else:
        main()
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, 'timkiem')
    T = {
        'The Movie Database': 'fsmdb_full',
        'Phim lẻ': 'tvhd_phimle',
        'Phim bộ': 'tvhd_phimbo',
        'Nhạc': 'tvhd_nhac'}
    dulieu = {
        'Phim lẻ mới':f'{ufn}/genre/phim-le',
        'Phim bộ mới':f'{ufn}/genre/series',
        'Thuyết minh':f'{ufn}/genre/thuyet-minh-tieng-viet',
        'Lồng tiếng':f'{ufn}/genre/long-tieng-tieng-viet',
        'H265':f'{ufn}/genre/h265',
        '3D':f'{ufn}/genre/3d',
        '4K':f'{ufn}/genre/4k',
        'ATV':f'{ufn}/genre/atv',
        'Bluray':f'{ufn}/genre/bluray-nguyen-goc',
        'TVB':f'{ufn}/genre/tvb',
        'Bộ sưu tập':f'{ufn}/genre/collection',
        'TV Shows':f'{ufn}/genre/tv-show',
        'TV':f'{ufn}/genre/tv',
        'Phim truyền hình':f'{ufn}/genre/tv-movie',
        'Phim hoạt hình':f'{ufn}/genre/animation',
        'Phim 18':f'{ufn}/genre/18'
        }
    for b in T:
        addDir(b, ICON, b, None, T[b])
    for h in dulieu:
        addDir(h, ICON, h, None, 'thuvienhd_page', url = f'{dulieu[h]}/page/', p=1)
    addDir('Góc chia sẻ', ICON, 'Góc chia sẻ', None, 'index_gcs')
    endOfDirectory(HANDLE)
def timkiem(query):
    search_query = quote_plus(query)
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(get_tkfs1, search_query)
        f2 = ex.submit(get_tkfs2, search_query)
    try:
        f1.result()
    except:
        pass
    try:
        f2.result()
    except:
        pass
    endOfDirectory(HANDLE)
def timkiem_fsmdb(query):
    search_query = quote_plus(query)
    url = f'{tmdbAPI}/search/multi?api_key={apiKey}&query={search_query}'
    next_page = 1
    fsmdb(url, next_page)
    endOfDirectory(HANDLE)
def find():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, None, 'tim_fs', key = m)
    endOfDirectory(HANDLE)
def find_fsmdb():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, 'search_fsmdb')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, m, None, 'tim_fsmdb', key = m)
    endOfDirectory(HANDLE)
def fsmdb(url, next_page):
    u = f'{url}&page={next_page}'
    r = getlink(u, u, 1000)
    rj = r.json()
    for k in rj['results']:
        if 'known_for' in k:
            s = k['known_for'][0]
            try:
                ten = s['name']
            except:
                ten = s['title']
        else:
            try:
                ten = k['name']
            except:
                ten = k['title']
        addDir(ten, f"https://image.tmdb.org/t/p/w500{k['poster_path']}", k['overview'], None, 'id_fsmdb', u=u, id = k['id'])
    if next_page < rj['total_pages']:
        trang = str(next_page + 1)
        addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, 'ds_fsmdb', url = u, p=trang)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        main()
    elif params['mode'] == 'index_gcs':
        index_gcs()
    elif params['mode'] == 'tvhd_phimle':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/phim-le',
            '3D': f'{ufn}/genre/3d',
            '4K': f'{ufn}/genre/4k',
            'Âm Nhạc': f'{ufn}/genre/am-nhac',
            'Ấn Độ': f'{ufn}/genre/india',
            'Bản quyền': f'{ufn}/genre/copyright',
            'Bí Ẩn': f'{ufn}/genre/bi-an',
            'Cao Bồi': f'{ufn}/genre/western',
            'Chiến Tranh': f'{ufn}/genre/war',
            'Chính Kịch': f'{ufn}/genre/chinh-kich',
            'Cổ Trang': f'{ufn}/genre/co-trang-phim',
            'Gây cấn': f'{ufn}/genre/gay-can',
            'Gia Đình': f'{ufn}/genre/gia-dinh',
            'Hài': f'{ufn}/genre/comedy',
            'Hàn Quốc': f'{ufn}/genre/korean',
            'Hành Động': f'{ufn}/genre/action',
            'Hình Sự': f'{ufn}/genre/crime',
            'Hồi hộp': f'{ufn}/genre/hoi-hop',
            'Hongkong': f'{ufn}/genre/hongkong',
            'Huyền Bí': f'{ufn}/genre/mystery',
            'Kinh Dị': f'{ufn}/genre/horror',
            'Lãng Mạn': f'{ufn}/genre/romance',
            'Lịch Sử': f'{ufn}/genre/history',
            'Nhạc Kịch': f'{ufn}/genre/nhac-kich',
            'Phiêu Lưu': f'{ufn}/genre/adventure',
            'Rùng Rợn': f'{ufn}/genre/thriller',
            'Tâm Lý': f'{ufn}/genre/drama',
            'Thần Thoại': f'{ufn}/genre/fantasy',
            'Thể Thao': f'{ufn}/genre/the-thao',
            'Thiếu Nhi': f'{ufn}/genre/family',
            'Tiểu Sử': f'{ufn}/genre/tieu-su',
            'Tình Cảm': f'{ufn}/genre/tinh-cam',
            'Tội Phạm': f'{ufn}/genre/toi-pham',
            'Trinh Thám': f'{ufn}/genre/trinh-tham',
            'Trung Quốc': f'{ufn}/genre/trung-quoc-series',
            'Viễn Tưởng': f'{ufn}/genre/sci-fi',
            'Việt Nam': f'{ufn}/genre/vietnamese',
            'Võ Thuật': f'{ufn}/genre/vo-thuat-phim-2',
            'Giáng Sinh': f'{ufn}/genre/giang-sinh',
            'Phim Hoạt Hình': f'{ufn}/genre/animation',
            'Phim Tài Liệu': f'{ufn}/genre/documentary',
            'Phim': f'{ufn}/genre/phim'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_phimbo':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/series',
            'Phim Bộ Nigeria': f'{ufn}/genre/phi-bo-nigeria',
            'Phim Bộ Ả Rập': f'{ufn}/genre/phim-bo-a-rap',
            'Phim Bộ Ai Cập': f'{ufn}/genre/phim-bo-ai-cap',
            'Phim Bộ Ái Nhĩ Lan (Ireland)': f'{ufn}/genre/phim-bo-ai-nhi-lan-ireland',
            'Phim Bộ Ấn Độ': f'{ufn}/genre/phim-bo-an-do',
            'Phim bộ Anh': f'{ufn}/genre/phim-bo-anh',
            'Phim Bộ Áo': f'{ufn}/genre/phim-bo-ao',
            'Phim Bộ Argentina': f'{ufn}/genre/phim-bo-argentina',
            'Phim Bộ Australia': f'{ufn}/genre/phim-bo-australia',
            'Phim Bộ Ba Lan': f'{ufn}/genre/phim-bo-ba-lan',
            'Phim Bộ Bỉ': f'{ufn}/genre/phim-bo-bi',
            'Phim Bộ Bồ Đào Nha': f'{ufn}/genre/phim-bo-bo-dao-nha',
            'Phim Bộ Brazil': f'{ufn}/genre/phim-bo-brazil',
            'Phim Bộ Canada': f'{ufn}/genre/phim-bo-canada',
            'Phim Bộ Chile': f'{ufn}/genre/phim-bo-chile',
            'Phim Bộ Colombia': f'{ufn}/genre/phim-bo-colombia',
            'Phim Bộ Đài Loan': f'{ufn}/genre/phim-bo-dai-loan',
            'Phim Bộ Đan Mạch': f'{ufn}/genre/phim-bo-dan-mach',
            'Phim Bộ Đức': f'{ufn}/genre/phim-bo-duc',
            'Phim Bộ Hà Lan': f'{ufn}/genre/phim-bo-ha-lan',
            'Phim Bộ Hàn': f'{ufn}/genre/korean-series',
            'Phim Bộ Hongkong': f'{ufn}/genre/hongkong-series',
            'Phim Bộ Iceland': f'{ufn}/genre/phim-bo-iceland',
            'Phim Bộ Ireland': f'{ufn}/genre/phim-bo-ireland',
            'Phim Bộ Israel': f'{ufn}/genre/phim-bo-israel',
            'Phim Bộ Jordan': f'{ufn}/genre/phim-bo-jordan',
            'Phim Bộ Mexico': f'{ufn}/genre/phim-bo-mexico',
            'Phim Bộ Mỹ': f'{ufn}/genre/us-tv-series',
            'Phim Bộ Na Uy': f'{ufn}/genre/phim-bo-na-uy',
            'Phim Bộ Nam Phi': f'{ufn}/genre/phim-bo-nam-phi',
            'Phim Bộ New Zealand': f'{ufn}/genre/phim-bo-new-zealand',
            'Phim Bộ Nga': f'{ufn}/genre/phim-bo-nga',
            'Phim Bộ Nhật Bản': f'{ufn}/genre/phim-bo-nhat-ban',
            'Phim Bộ Phần Lan': f'{ufn}/genre/phim-bo-phan-lan',
            'Phim Bộ Pháp': f'{ufn}/genre/phim-bo-phap',
            'Phim Bộ Philippines': f'{ufn}/genre/phim-bo-philippines',
            'Phim Bộ Romania': f'{ufn}/genre/phim-bo-romania',
            'Phim Bộ Singapo': f'{ufn}/genre/phim-bo-singapo',
            'Phim Bộ Tây Ban Nha': f'{ufn}/genre/phim-bo-tay-ban-nha',
            'Phim Bộ Thái Lan': f'{ufn}/genre/phim-bo-thai-lan',
            'Phim Bộ Thổ Nhĩ Kỳ': f'{ufn}/genre/phim-bo-tho-nhi-ky',
            'Phim Bộ Thụy Điển': f'{ufn}/genre/phim-bo-thuy-dien',
            'Phim Bộ Trung Quốc': f'{ufn}/genre/phim-bo-trung-quoc',
            'Phim Bộ Việt Nam': f'{ufn}/genre/phim-bo-viet-nam',
            'Phim Bộ Ý': f'{ufn}/genre/phim-bo-y'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_nhac':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/music',
            'Chương Trình Xuân': f'{ufn}/genre/chuong_trinh-xuan',
            'Lossless': f'{ufn}/genre/lossless',
            'MV Châu Á': f'{ufn}/genre/wp-chau-a',
            'MV Quốc Tế': f'{ufn}/genre/wp-quoc-te',
            'MV Việt Nam': f'{ufn}/genre/wp-viet-nam'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'fsmdb_full':
        addDir('Tìm phim', searchimg, 'Tìm phim', None, 'timkiem_fsmdb')
        T = {'Phân loại phim lẻ': 'fsmdb_phimle',
            'Phân loại phim bộ': 'fsmdb_phimbo'}
        dulieu = {
            'Trending': f'{tmdbAPI}/trending/all/day?api_key={apiKey}',
            'Popular Movies': f'{tmdbAPI}/movie/popular?api_key={apiKey}',
            'Popular TV Shows': f'{tmdbAPI}/tv/popular?api_key={apiKey}',
            'Airing Today TV Shows': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}',
            'Netflix': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=213',
            'Amazon': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=1024',
            'Disney+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=2739',
            'Hulu': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=453',
            'Apple TV+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=2552',
            'HBO': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=49',
            'Paramount+': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_networks=4330',
            'Top Rated Movies': f'{tmdbAPI}/movie/top_rated?api_key={apiKey}',
            'Top Rated TV Shows': f'{tmdbAPI}/tv/top_rated?api_key={apiKey}',
            'Upcoming Movies': f'{tmdbAPI}/movie/upcoming?api_key={apiKey}',
            'Phim lẻ HQ': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_original_language=ko',
            'Phim bộ HQ': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_original_language=ko',
            'Phim lẻ TQ': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_original_language=zh',
            'Phim bộ TQ': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_original_language=zh',
            'Airing Today Anime': f'{tmdbAPI}/tv/airing_today?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
            'Ongoing Anime': f'{tmdbAPI}/tv/on_the_air?api_key={apiKey}&with_keywords=210024|222243&sort_by=primary_release_date.desc',
            'Anime': f'{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_keywords=210024|222243',
            'Anime Movies': f'{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_keywords=210024|222243'
            }
        for b in T:
            addDir(b, ICON, b, None, T[b])
        for k in dulieu:
            addDir(k, ICON, k, None, 'ds_fsmdb', url = dulieu[k], p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'fsmdb_phimle':
        u = f'{tmdbAPI}/genre/movie/list?api_key={apiKey}'
        r = getlink(u, u, 600)
        dulieu = r.json()['genres']
        for k in dulieu:
            ten = k['name']
            url = f"{tmdbAPI}/discover/movie?api_key={apiKey}&sort_by=popularity.desc&with_genres={k['id']}"
            addDir(ten, ICON, ten, None, 'ds_fsmdb', url = url, p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'fsmdb_phimbo':
        u = f'{tmdbAPI}/genre/tv/list?api_key={apiKey}'
        r = getlink(u, u, 1000)
        dulieu = r.json()['genres']
        for k in dulieu:
            ten = k['name']
            url = f"{tmdbAPI}/discover/tv?api_key={apiKey}&sort_by=popularity.desc&with_genres={k['id']}"
            addDir(ten, ICON, ten, None, 'ds_fsmdb', url = url, p=1)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'ds_fsmdb':
        next_page = int(params["p"])
        url = params["url"]
        fsmdb(url, next_page)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'id_fsmdb':
        idp = params["id"]
        u = params["u"]
        if '/tv/' in u:
            url = f'{tmdbAPI}/tv/{idp}?api_key={apimdb}&language=en-US'
        else:
            url = f'{tmdbAPI}/movie/{idp}?api_key={apimdb}&language=en-US'
        r = getlink(url, url, 1000)
        timkiem(r.json()['title'])
    elif params['mode'] =='search_fsmdb':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem_fsmdb(query)
        else:
            find_fsmdb()
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query)
        else:
            find()
    elif params['mode'] =='timvmf':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_query = quote_plus(query)
            url = f"{params['link']}{search_query}"
            listvmf_gcs(url)
            endOfDirectory(HANDLE)
        else:
            index_gcs()
    elif params['mode'] =='timkiem':
        find()
    elif params['mode'] =='timkiem_fsmdb':
        find_fsmdb()
    elif params['mode'] =='tim_fs':
        timkiem(params['key'])
    elif params['mode'] =='tim_fsmdb':
        timkiem_fsmdb(params['key'])
    elif params['mode'] == 'thuvienhd_page':
        next_page = int(params["p"])
        trangtiep = f'{params["url"]}{next_page}'
        resp = getlink(trangtiep, trangtiep, 1000)
        root = resp.parse().iterfind('.//div[@class="items"]//article')
        for k in root:
            name = domhtml(k, './/div[@class="data"]//a')
            img = domhtml(k, './/div[@class="poster"]//img', attribute='src')
            texto = domhtml(k, './/div[@class="texto"]', default=name)
            idp = k.get('id').split('-')[1] if k.get('id') else ''
            addDir(name, img, texto, None, 'thuvienhd_link', idk = idp, info = texto, ground = img)
        if 'nextpagination' in resp.text:
            trang = str(next_page + 1)
            addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, 'thuvienhd_page', url = params["url"], p=trang)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'thuvienhd_link':
        url = params['idk']
        mota = params['info']
        anh = params['ground']
        t = f'{ufn}/download?id={params["idk"]}'
        resp = getlink(t, t, 1000)
        root = resp.parse().iterfind('.//tbody[@class="tbody outer"]//tr//td//a[@class="face-button"]')
        for k in root:
            link = k.get('href')
            if 'fshare.vn' in link:
                name = k.get('title')
                if 'folder' in link:
                    addDir(name, anh, mota, None, 'index_fs', link = link, p=1)
                else:
                    size = k.find('.//div[@class="face-secondary"]')
                    size_text = convert_to_kb(''.join(size.itertext()).strip())
                    addDir(name, anh, mota, size_text, 'play_fs', link = link, tenphim = name, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'listvmf_gcs':
        url = params['link']
        listvmf_gcs(url)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'listgg_gcs':
        url = params['link']
        listgg_gcs(url)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'index_fs':
        folderfs = re.search(r'/(folder|file)/([A-Z0-9]+)', params['link'])[2]
        next_page = int(params['p'])
        u = f'https://www.fshare.vn/api/v3/files/folder?linkcode={folderfs}&sort=type%2Cname&page={next_page}&per-page=50'
        r = getlink(u, u, 400)
        for k in r.json()['items']:
            tenm = k['name']
            if k['type'] == 1:
                linkfs = f'https://www.fshare.vn/file/{k["linkcode"]}'
                addDir(tenm, ICON, tenm, k['size'], 'play_fs', link = linkfs, tenphim = tenm, is_folder=False)
            else:
                linkfs = f'https://www.fshare.vn/folder/{k["linkcode"]}'
                addDir(tenm, ICON, tenm, None, 'index_fs', link = linkfs, p=1)
        if 'next' in r.json()['_links']:
            linkfds = f'https://www.fshare.vn/folder/{folderfs}'
            trang = str(next_page + 1)
            addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, 'index_fs', link = linkfds, p=trang)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_fs':
        j = userpassfs()
        payload = {'zipflag':0, 'url': params['link'], 'password':'', 'token': j[0]}
        headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={j[1]}', 'content-type': 'application/json; charset=utf-8'}
        with Session() as s:
            uf = s.post('https://api.fshare.vn/api/session/download', timeout=30,data=dumps(payload),headers=headerfsvn)
        if 'location' in uf.text:
            play_item = xbmcgui.ListItem(offscreen=True)
            linkplay = re.sub(r'\s+', '%20', uf.json()['location'].strip(), flags=re.UNICODE)
            play_item.setPath(linkplay)
            setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play_vnm':
        play_item = xbmcgui.ListItem(offscreen=True)
        if params.get('sub') is not None:
            play_item.setSubtitles([params['sub']])
        url = params['link']
        uplay = url[6:]
        if 'm3u8' in uplay:
            if any((re.search(r':(?!/)', uplay), ('?' in uplay))):
                linkplay = re.sub(r'\s+', '%20', url.strip(), flags=re.UNICODE)
                play_item.setPath(f'{linkplay}|verifypeer=false&User-Agent={unquote(UA)}')
            elif '|' in uplay:
                d = url.split('|')
                play_item.setProperty('inputstream', 'inputstream.adaptive')
                play_item.setProperty('inputstream.adaptive.stream_headers', d[1])
                play_item.setProperty('inputstream.adaptive.manifest_headers', d[1])
                play_item.setPath(d[0])
            else:
                hdr = f'User-Agent={UA}'
                play_item.setProperty('inputstream', 'inputstream.adaptive')
                play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
                play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
                play_item.setPath(url)
        else:
            linkplay = re.sub(r'\s+', '%20', url.strip(), flags=re.UNICODE)
            play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])