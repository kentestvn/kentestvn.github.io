from urllib.parse import urlencode, parse_qsl, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmc import executebuiltin
from xbmcvfs import translatePath
from requests import Session
from json import loads, dumps
from concurrent.futures import ThreadPoolExecutor
from collections import OrderedDict
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP2A.241205) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/605.1.15 EdgA/131.0.0.0'
ufn = 'https://thuvienhd.xyz'
userfs = 'FshareiOSApp-saCP7ssw2u7w'
keyfs = 'MkywVt2UBRHcJXUUcfsZ7XXzBSJV3dwE'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title=None, img=None, plot=None, size=None, mode=None, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if size is not None:
        list_item.setInfo(type='Video', infoLabels={'size': size})
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def get_tkfs1(search_query):
    r = getlink(f'http://phongblack.online/search-tungbui.php?author=phongblack&search={search_query}', 'http://www.google.com', 1000)
    for item in r.json()['items']:
        if not item.get('is_playable', False) and 'fshare' in item['path']:
            label = item['label']
            url = re.search(r"url=(\S+)", item['path'])[1]
            plot = item['info']['plot']
            if '/file/' in url:
                addDir(label, ICON, plot, None, 'play_fs', link = url, tenphim = label, is_folder=False)
            else:
                addDir(label, ICON, plot, None, 'index_fs', link = url, p=1, is_folder=True)
def get_tkfs2(search_query):
    urlx = f'https://api.timfshare.com/v1/string-query-search?query={search_query}'
    headers = {
        'user-agent': UA,
        'referer': 'https://timfshare.com/',
        'authorization': 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJuYW1lIjoiZnNoYXJlIiwidXVpZCI6IjcxZjU1NjFkMTUiLCJ0eXBlIjoicGFydG5lciIsImV4cGlyZXMiOjAsImV4cGlyZSI6MH0.WBWRKbFf7nJ7gDn1rOgENh1_doPc07MNsKwiKCJg40U'
    }
    response = urlquick.post(urlx, timeout=30, max_age=1000, headers=headers)
    data = response.json().get('data', [])
    for item in data:
        name = item['name']
        url = item['url']
        size = item['size']
        if 'folder' in url:
            addDir(name, ICON, name, None, 'index_fs', link = url, p=1, is_folder=True)
        else:
            addDir(name, ICON, name, size, 'play_fs', link = url, tenphim = name, is_folder=False)
def get_tkfs3(search_query):
    u = f'{ufn}/?feed=fsharejson&search={search_query}'
    r1 = getlink(u, ufn, 1000)
    r2 = getlink(f'{ufn}/?feed=fsharejson&search=', ufn, 1000)
    for t in r1.json():
        if r1.content != r2.content:
            img = t['image']
            name = t['title'].replace('&&','-')
            addDir(name, t['image'], name, None, 'thuvienhd_link', idk = t['id'], info = name, ground = img, is_folder=True)
def get_tkfs4():
    u = f'{ufn}/?feed=fsharejson&search={search_query}'
    r1 = getlink(u, ufn, 1000)
    r2 = getlink(f'{ufn}/?feed=fsharejson&search=', ufn, 1000)
    rj = loads(re.sub(r'<(.*?)\n','', r.text))
    for t in rj:
        if r1.content != r2.content:
            img = t['image']
            name = t['title'].replace('&&','-')
            addDir(name, t['image'], name, None, 'thuvienhd_link', idk = t['id'], info = name, ground = img, is_folder=True)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def has_file_path(filename):
    return os.path.exists(get_file_path(filename))
def remove_file(filename):
    if has_file_path(filename):
        os.remove(get_file_path(filename))
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        with open(get_file_path(name), mode=read_mode) as f:
            content = f.read()
    except:
        pass
    return content
def write_file(name, content, binary=False):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(name)
    try:
        write_mode = 'wb+' if binary else 'w+'
        with open(path, mode=write_mode) as f:
            f.write(content)
    except:
        pass
    return path
def save_last_watch_movie(data):
    if not data:
        return
    content = read_file('watcheds.json')
    content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
    cache_id, query = data
    content.update({cache_id: query})
    content.move_to_end(cache_id, last=False)
    while len(content) > 20:
        content.popitem(last=True)
    write_file('watcheds.json', dumps(content))
def search_history_save(search_key):
    if not search_key:
        return
    content = read_file('historys.json')
    content = loads(content) if content else []
    idx = next((content.index(i) for i in content if search_key == i), -1)
    if (idx >= 0) and (len(content) > 0):
        del content[idx]
    elif len(content) >= 20:
        content.pop()
    content.insert(0, search_key)
    write_file('historys.json', dumps(content))
def search_history_get():
    content = read_file('historys.json')
    content = loads(content) if content else []
    return content
def convert_to_kb(size_str):
    size_str = size_str.strip().lower()
    if "gb" in size_str:
        size_in_gb = float(size_str.replace("gb", "").strip())
        return int(size_in_gb * 1024 * 1024 * 1024)
    elif "mb" in size_str:
        size_in_mb = float(size_str.replace("mb", "").strip())
        return int(size_in_mb * 1024 * 1024)
    elif "kb" in size_str:
        size_in_kb = float(size_str.replace("kb", "").strip())
        return int(size_in_kb * 1024)
    else:
        return None
def userpassfs():
    username = Addon().getSetting('username')
    password = Addon().getSetting('password')
    if username and password:
        payload = {'user_email':username,'password':password,'app_key':keyfs}
        head = {'user-agent':userfs, 'content-type': 'application/json; charset=utf-8'}
        try:
            response = urlquick.post('https://api.fshare.vn/api/user/login',data=dumps(payload),headers=head,timeout=30,max_age=7200)
            headerfsvn = {'user-agent':userfs, 'cookie' : f"session_id={response.json()['session_id']}"}
            with Session() as s:
                r = s.get('https://api.fshare.vn/api/user/get', timeout=30, headers=headerfsvn)
            if r.status_code == 200:
                return (response.json()['token'], response.json()['session_id'])
            else:
                urlquick.cache_cleanup(-1)
                remove_file('.urlquick.slite3')
                userpassfs()
        except:
            urlquick.cache_cleanup(-1)
            remove_file('.urlquick.slite3')
            executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Đăng nhập thất bại', 5000, ICON))
            sys.exit()
    else:
        executebuiltin('Notification("%s", "%s", "%d", "%s")' % (addon_name, 'Vui lòng nhập tài khoản Fshare trong cài đặt của VN Media', 5000, ICON))
        sys.exit()
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', None, 'search', is_folder=True)
    T = {'Lịch sử tìm kiếm': 'lichsutim',
        'Phim lẻ': 'tvhd_phimle',
        'Phim bộ': 'tvhd_phimbo',
        'Nhạc': 'tvhd_nhac'}
    dulieu = {
        'Phim lẻ mới':f'{ufn}/genre/phim-le',
        'Phim bộ mới':f'{ufn}/genre/series',
        'Thuyết minh':f'{ufn}/genre/thuyet-minh-tieng-viet',
        'Lồng tiếng':f'{ufn}/genre/long-tieng-tieng-viet',
        'H265':f'{ufn}/genre/h265',
        '3D':f'{ufn}/genre/3d',
        '4K':f'{ufn}/genre/4k',
        'ATV':f'{ufn}/genre/atv',
        'Bluray':f'{ufn}/genre/bluray-nguyen-goc',
        'TVB':f'{ufn}/genre/tvb',
        'Bộ sưu tập':f'{ufn}/genre/collection',
        'TV Shows':f'{ufn}/genre/tv-show',
        'TV':f'{ufn}/genre/tv',
        'Phim truyền hình':f'{ufn}/genre/tv-movie',
        'Phim hoạt hình':f'{ufn}/genre/animation',
        'Phim 18':f'{ufn}/genre/18'
        }
    for b in T:
        addDir(b, ICON, b, None, T[b], is_folder=True)
    for h in dulieu:
        addDir(h, ICON, h, None, 'thuvienhd_page', url = f'{dulieu[h]}/page/', p=1, is_folder=True)
    endOfDirectory(HANDLE)
def timkiem(search_query):
    with ThreadPoolExecutor(4) as ex:
        f1 = ex.submit(get_tkfs1, search_query)
        f2 = ex.submit(get_tkfs2, search_query)
        f3 = ex.submit(get_tkfs3, search_query)
        f4 = ex.submit(get_tkfs4, search_query)
    try:
        f3.result()
    except:
        f4.result()
    try:
        f1.result()
    except:
        pass
    try:
        f2.result()
    except:
        pass
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        main()
    elif params['mode'] == 'tvhd_phimle':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/phim-le',
            '3D': f'{ufn}/genre/3d',
            '4K': f'{ufn}/genre/4k',
            'Âm Nhạc': f'{ufn}/genre/am-nhac',
            'Ấn Độ': f'{ufn}/genre/india',
            'Bản quyền': f'{ufn}/genre/copyright',
            'Bí Ẩn': f'{ufn}/genre/bi-an',
            'Cao Bồi': f'{ufn}/genre/western',
            'Chiến Tranh': f'{ufn}/genre/war',
            'Chính Kịch': f'{ufn}/genre/chinh-kich',
            'Cổ Trang': f'{ufn}/genre/co-trang-phim',
            'Gây cấn': f'{ufn}/genre/gay-can',
            'Gia Đình': f'{ufn}/genre/gia-dinh',
            'Hài': f'{ufn}/genre/comedy',
            'Hàn Quốc': f'{ufn}/genre/korean',
            'Hành Động': f'{ufn}/genre/action',
            'Hình Sự': f'{ufn}/genre/crime',
            'Hồi hộp': f'{ufn}/genre/hoi-hop',
            'Hongkong': f'{ufn}/genre/hongkong',
            'Huyền Bí': f'{ufn}/genre/mystery',
            'Kinh Dị': f'{ufn}/genre/horror',
            'Lãng Mạn': f'{ufn}/genre/romance',
            'Lịch Sử': f'{ufn}/genre/history',
            'Nhạc Kịch': f'{ufn}/genre/nhac-kich',
            'Phiêu Lưu': f'{ufn}/genre/adventure',
            'Rùng Rợn': f'{ufn}/genre/thriller',
            'Tâm Lý': f'{ufn}/genre/drama',
            'Thần Thoại': f'{ufn}/genre/fantasy',
            'Thể Thao': f'{ufn}/genre/the-thao',
            'Thiếu Nhi': f'{ufn}/genre/family',
            'Tiểu Sử': f'{ufn}/genre/tieu-su',
            'Tình Cảm': f'{ufn}/genre/tinh-cam',
            'Tội Phạm': f'{ufn}/genre/toi-pham',
            'Trinh Thám': f'{ufn}/genre/trinh-tham',
            'Trung Quốc': f'{ufn}/genre/trung-quoc-series',
            'Viễn Tưởng': f'{ufn}/genre/sci-fi',
            'Việt Nam': f'{ufn}/genre/vietnamese',
            'Võ Thuật': f'{ufn}/genre/vo-thuat-phim-2',
            'Giáng Sinh': f'{ufn}/genre/giang-sinh',
            'Phim Hoạt Hình': f'{ufn}/genre/animation',
            'Phim Tài Liệu': f'{ufn}/genre/documentary',
            'Phim': f'{ufn}/genre/phim'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_phimbo':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/series',
            'Phim Bộ Nigeria': f'{ufn}/genre/phi-bo-nigeria',
            'Phim Bộ Ả Rập': f'{ufn}/genre/phim-bo-a-rap',
            'Phim Bộ Ai Cập': f'{ufn}/genre/phim-bo-ai-cap',
            'Phim Bộ Ái Nhĩ Lan (Ireland)': f'{ufn}/genre/phim-bo-ai-nhi-lan-ireland',
            'Phim Bộ Ấn Độ': f'{ufn}/genre/phim-bo-an-do',
            'Phim bộ Anh': f'{ufn}/genre/phim-bo-anh',
            'Phim Bộ Áo': f'{ufn}/genre/phim-bo-ao',
            'Phim Bộ Argentina': f'{ufn}/genre/phim-bo-argentina',
            'Phim Bộ Australia': f'{ufn}/genre/phim-bo-australia',
            'Phim Bộ Ba Lan': f'{ufn}/genre/phim-bo-ba-lan',
            'Phim Bộ Bỉ': f'{ufn}/genre/phim-bo-bi',
            'Phim Bộ Bồ Đào Nha': f'{ufn}/genre/phim-bo-bo-dao-nha',
            'Phim Bộ Brazil': f'{ufn}/genre/phim-bo-brazil',
            'Phim Bộ Canada': f'{ufn}/genre/phim-bo-canada',
            'Phim Bộ Chile': f'{ufn}/genre/phim-bo-chile',
            'Phim Bộ Colombia': f'{ufn}/genre/phim-bo-colombia',
            'Phim Bộ Đài Loan': f'{ufn}/genre/phim-bo-dai-loan',
            'Phim Bộ Đan Mạch': f'{ufn}/genre/phim-bo-dan-mach',
            'Phim Bộ Đức': f'{ufn}/genre/phim-bo-duc',
            'Phim Bộ Hà Lan': f'{ufn}/genre/phim-bo-ha-lan',
            'Phim Bộ Hàn': f'{ufn}/genre/korean-series',
            'Phim Bộ Hongkong': f'{ufn}/genre/hongkong-series',
            'Phim Bộ Iceland': f'{ufn}/genre/phim-bo-iceland',
            'Phim Bộ Ireland': f'{ufn}/genre/phim-bo-ireland',
            'Phim Bộ Israel': f'{ufn}/genre/phim-bo-israel',
            'Phim Bộ Jordan': f'{ufn}/genre/phim-bo-jordan',
            'Phim Bộ Mexico': f'{ufn}/genre/phim-bo-mexico',
            'Phim Bộ Mỹ': f'{ufn}/genre/us-tv-series',
            'Phim Bộ Na Uy': f'{ufn}/genre/phim-bo-na-uy',
            'Phim Bộ Nam Phi': f'{ufn}/genre/phim-bo-nam-phi',
            'Phim Bộ New Zealand': f'{ufn}/genre/phim-bo-new-zealand',
            'Phim Bộ Nga': f'{ufn}/genre/phim-bo-nga',
            'Phim Bộ Nhật Bản': f'{ufn}/genre/phim-bo-nhat-ban',
            'Phim Bộ Phần Lan': f'{ufn}/genre/phim-bo-phan-lan',
            'Phim Bộ Pháp': f'{ufn}/genre/phim-bo-phap',
            'Phim Bộ Philippines': f'{ufn}/genre/phim-bo-philippines',
            'Phim Bộ Romania': f'{ufn}/genre/phim-bo-romania',
            'Phim Bộ Singapo': f'{ufn}/genre/phim-bo-singapo',
            'Phim Bộ Tây Ban Nha': f'{ufn}/genre/phim-bo-tay-ban-nha',
            'Phim Bộ Thái Lan': f'{ufn}/genre/phim-bo-thai-lan',
            'Phim Bộ Thổ Nhĩ Kỳ': f'{ufn}/genre/phim-bo-tho-nhi-ky',
            'Phim Bộ Thụy Điển': f'{ufn}/genre/phim-bo-thuy-dien',
            'Phim Bộ Trung Quốc': f'{ufn}/genre/phim-bo-trung-quoc',
            'Phim Bộ Việt Nam': f'{ufn}/genre/phim-bo-viet-nam',
            'Phim Bộ Ý': f'{ufn}/genre/phim-bo-y'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'tvhd_nhac':
        dulieu = {
            'Mới nhất':f'{ufn}/genre/music',
            'Chương Trình Xuân': f'{ufn}/genre/chuong_trinh-xuan',
            'Lossless': f'{ufn}/genre/lossless',
            'MV Châu Á': f'{ufn}/genre/wp-chau-a',
            'MV Quốc Tế': f'{ufn}/genre/wp-quoc-te',
            'MV Việt Nam': f'{ufn}/genre/wp-viet-nam'
        }
        for k in dulieu:
            addDir(k, ICON, k, None, 'thuvienhd_page', url = f'{dulieu[k]}/page/', p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            search_query = quote_plus(query)
            timkiem(search_query)
        else:
            main()
    elif params['mode'] =='lichsutim':
        b = search_history_get()
        if b:
            for m in b:
                addDir(m, ICON, m, None, 'tim_fs', key = m, is_folder=True)
            endOfDirectory(HANDLE)
    elif params['mode'] =='tim_fs':
        search_query = quote_plus(params['key'])
        timkiem(search_query)
    elif params['mode'] == 'thuvienhd_page':
        next_page = int(params["p"])
        trangtiep = f'{params["url"]}{next_page}'
        resp = getlink(trangtiep, trangtiep, 1000)
        root = resp.parse("div", attrs={"class": "items"})
        for k in root.iterfind('.//article'):
            name_element = k.find('.//div[@class="data"]//a')
            name = name_element.text.strip() if name_element is not None else ''
            img_element = k.find('.//div[@class="poster"]//img')
            img = img_element.get('src') if img_element is not None else ''
            texto_element = k.find('.//div[@class="texto"]')
            texto = texto_element.text.strip() if texto_element is not None and texto_element.text else name
            idp = k.get('id').split('-')[1] if k.get('id') else ''
            addDir(name, img, texto, None, 'thuvienhd_link', idk = idp, info = texto, ground = img, is_folder=True)
        if "nextpagination" in resp.text:
            trang = str(next_page + 1)
            addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, 'thuvienhd_page', url = params["url"], p=trang, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'thuvienhd_link':
        url = params['idk']
        mota = params['info']
        anh = params['ground']
        t = f'{ufn}/download?id={params["idk"]}'
        resp = getlink(t, t, 1000)
        root = resp.parse("tbody", attrs={"class": "tbody outer"})
        for k in root.iterfind('.//tr//td//a[@class="face-button"]'):
            link = k.get('href')
            if 'fshare.vn' in link:
                name = k.get('title')
                if 'folder' in link:
                    addDir(name, anh, mota, None, 'index_fs', link = link, p=1, is_folder=True)
                else:
                    size = k.find('.//div[@class="face-secondary"]')
                    size_text = convert_to_kb(''.join(size.itertext()).strip())
                    addDir(name, anh, mota, size_text, 'play_fs', link = link, tenphim = name, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'index_fs':
        folderfs = re.search(r'/(folder|file)/([A-Z0-9]+)', params['link'])[2]
        next_page = int(params['p'])
        u = f'https://www.fshare.vn/api/v3/files/folder?linkcode={folderfs}&sort=type%2Cname&page={next_page}&per-page=50'
        r = getlink(u, u, 400)
        for k in r.json()['items']:
            tenm = k['name']
            if k['type'] == 1:
                linkfs = f'https://www.fshare.vn/file/{k["linkcode"]}'
                addDir(tenm, ICON, tenm, k['size'], 'play_fs', link = linkfs, tenphim = tenm, is_folder=False)
            else:
                linkfs = f'https://www.fshare.vn/folder/{k["linkcode"]}'
                addDir(tenm, ICON, tenm, None, 'index_fs', link = linkfs, p=1, is_folder=True)
        if 'next' in r.json()['_links']:
            linkfds = f'https://www.fshare.vn/folder/{folderfs}'
            trang = str(next_page + 1)
            addDir(f'Trang {trang}', nextimg, f'Trang {trang}', None, 'index_fs', link = linkfds, p=trang, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_fs':
        j = userpassfs()
        payload = {'zipflag':0, 'url': params['link'], 'password':'', 'token': j[0]}
        headerfsvn = {'user-agent':userfs, 'cookie' : f'session_id={j[1]}', 'content-type': 'application/json; charset=utf-8'}
        with Session() as s:
            uf = s.post('https://api.fshare.vn/api/session/download', timeout=30,data=dumps(payload),headers=headerfsvn)
        if 'location' in uf.text:
            save_last_watch_movie((params['tenphim'], params['link']))
            play_item = xbmcgui.ListItem(offscreen=True)
            linkplay = re.sub(r'\s+', '%20', uf.json()['location'].strip(), flags=re.UNICODE)
            play_item.setPath(linkplay)
            setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])