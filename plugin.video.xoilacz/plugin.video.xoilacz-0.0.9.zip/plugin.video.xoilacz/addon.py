from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from htmlement import fromstring
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP2A.240805.005) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
xoilac = 'https://xoilacz.co'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')}, verify=False)
    r.encoding = 'utf-8'
    return r
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        url = f'{xoilac}/sport/football/filter/all'
        r = getlink(url, url, 400)
        root = fromstring(r.json()['data']['html'])
        for k in root.iterfind('.//div[@class="grid-matches__item mb-3"]'):
            link_element = k.find('.//a')
            link = link_element.get('href') if link_element is not None else ''
            linkplay = f'{xoilac}{link}' if link.startswith('/') else link
            date = k.find('.//div[@class="grid-match__date"]')
            date_text = ''.join(date.itertext()).strip()
            date_parts = date_text.split()
            formatted_date = ' '.join(date_parts)
            home_element = k.find('.//span[@class="grid-match__team--name grid-match__team--home-name"]')
            away_element = k.find('.//span[@class="grid-match__team--name grid-match__team--away-name"]')
            commentator_element = k.find('.//a[@class="d-flex align-items-center commentator gap-1"]')
            home = home_element.text.strip() if home_element is not None else ''
            away = away_element.text.strip() if away_element is not None else ''
            if commentator_element:
                ten = f'[COLOR yellow]{formatted_date} {home} vs {away}[/COLOR]'
            else:
                ten = f'{formatted_date} {home} vs {away}'
            addDir(ten, 'sv_91phut', k = linkplay, t = ten, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'sv_91phut':
        url = params["k"]
        name = params["t"]
        resp = getlink(url, url, 400)
        if 'link-video' in resp.text:
            soup = resp.parse("div", attrs={"class": "link-video"})
            for k in soup.iterfind('.//a'):
                ten = ''.join(k.itertext()).strip()
                ep = k.get('href')
                addDir(f'{ten} - {name}', 'ifr_bongda', ep = ep, t=params["t"], is_folder=False)
        elif 'tv_links' in resp.text:
            soup = resp.parse("div", attrs={"id": "tv_links"})
            for k in soup.iterfind('.//a'):
                ten = ''.join(k.itertext()).strip()
                ep = k.get('href')
                addDir(f'{ten} - {name}', 'ifr_bongda', ep = ep, t=params["t"], is_folder=False)
        else:
            addDir(name, 'ifr_bongda', ep = url, t=params["t"], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'ifr_bongda':
        play_item = xbmcgui.ListItem(offscreen=True)
        url = params["ep"]
        resp = getlink(url, url, -1)
        frame_element = resp.parse("iframe", attrs={"allowfullscreen": "true"})
        ifr = frame_element.get('src') if frame_element is not None else ''
        ifr = ifr if 'http' in ifr else f'{xoilac}{ifr}'
        ref = domain(ifr)
        r = getlink(ifr, url, -1)
        sre = re.compile(r'(https?://[^\s"]+\.m3u8[^"\']*)')
        linkstream = sre.search(r.text)[1]
        linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}/"
        if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
            linkplay = f'{linkplay}|{hdr}'
        else:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])