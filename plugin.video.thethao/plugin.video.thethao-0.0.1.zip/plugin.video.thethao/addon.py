from urllib.parse import urlencode, parse_qsl, unquote
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import re, sys, xbmcgui, requests
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
def addDir(title, img, mode, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img, 'fanart': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item)
class m3u:
    @staticmethod
    def convert(m3u_file: str):
        m3u_json = []
        lines = m3u_file.split("\n")
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith("#EXTINF"):
                channelInfo = {}
                try:
                    logoStartIndex = line.index('tvg-logo="') + 10
                    logoEndIndex = line.index('"', logoStartIndex)
                    logoUrl = line[logoStartIndex:logoEndIndex]
                except ValueError:
                    logoUrl = ""
                try:
                    groupTitleStartIndex = line.index('group-title="') + 13
                    groupTitleEndIndex = line.index('"', groupTitleStartIndex)
                    groupTitle = line[groupTitleStartIndex:groupTitleEndIndex]
                except ValueError:
                    groupTitle = ""
                titleStartIndex = line.rindex(",") + 1
                title = line[titleStartIndex:].strip() if "," in line else ""
                j = i + 1
                link = ""
                user_agent = ""
                referrer = ""
                while j < len(lines) and lines[j].startswith("#"):
                    if lines[j].startswith("#EXTVLCOPT:http-user-agent="):
                        user_agent = lines[j].split("=", 1)[1].strip()
                    elif lines[j].startswith("#EXTVLCOPT:http-referrer="):
                        referrer = lines[j].split("=", 1)[1].strip()
                    j += 1
                if j < len(lines):
                    link = lines[j].strip()
                channelInfo["tvg-logo"] = logoUrl
                channelInfo["group-title"] = groupTitle
                channelInfo["title"] = title
                channelInfo["link"] = link
                if user_agent:
                    channelInfo["user-agent"] = user_agent
                if referrer:
                    channelInfo["referrer"] = referrer
                m3u_json.append(channelInfo)
            i += 1
        return m3u_json
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        response = requests.get('https://raw.githubusercontent.com/nguoisuutam1985/bongda/main/bongda.m3u8')
        m3u_file_content = response.text
        m3u_json = m3u.convert(m3u_file_content)
        for k in m3u_json:
            logo = k.get('tvg-logo', ICON)
            nhom = k['group-title']
            name = k['title']
            link = k['link']
            title = f'[COLOR yellow]{nhom}[/COLOR] {name}'
            user_agent = k.get('user-agent')
            referrer = k.get('referrer')
            addDir(title, logo, 'play', id = link, UA=user_agent, ref=referrer)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        UA = params['UA']
        ref = params['ref']
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}/"
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f"{linkplay}|{hdr}"
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])