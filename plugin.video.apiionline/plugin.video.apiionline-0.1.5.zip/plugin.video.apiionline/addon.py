from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus, urljoin
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pathlib import Path
from html import unescape
import re, sys, urlquick, xbmcgui, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
uapi = 'https://apii.online/apii'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def limit_files_in_directory(directory):
    files = sorted(Path(directory).glob('*'), key=os.path.getmtime)
    while len(files) > 5:
        oldest_file = files.pop(0)
        try:
            oldest_file.unlink()
        except Exception as e:
            pass
def process_m3u8(url):
    response = getlink(url, url, 300)
    parsed_url = urlparse(url.strip())
    domain = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path.rsplit('/', 1)[0]}"
    lines = response.text.splitlines()
    for line in lines:
        if line.startswith('#EXTM3U'):
            continue
        elif line.startswith('#EXT-X-STREAM-INF'):
            next_line_index = lines.index(line) + 1
            if next_line_index < len(lines):
                sub_m3u8_path = lines[next_line_index].strip()
                new_url = urljoin(url, sub_m3u8_path)
                return process_m3u8(new_url)
        else:
            break
    sections = []
    current_section = []
    for line in lines:
        if line.startswith('#EXT-X-DISCONTINUITY'):
            if current_section:
                sections.append(current_section)
            current_section = [line]
        else:
            current_section.append(line)
    if current_section:
        sections.append(current_section)
    to_remove = set()
    discontinuity_indices = [i for i, section in enumerate(sections) if section[0].startswith('#EXT-X-DISCONTINUITY')]
    if len(discontinuity_indices) >= 2:
        to_remove.add(discontinuity_indices[0])
    for i in range(len(sections) - 1):
        if sections[i][0].startswith('#EXT-X-DISCONTINUITY') and len(sections[i]) > 1:
            if sections[i][1].startswith('#EXTINF:3.336667'):
                to_remove.add(i)
                if i > 0:
                    to_remove.add(i - 1)
    new_content = []
    for i, section in enumerate(sections):
        if i not in to_remove:
            new_content.extend(section)
    new_content_with_domain = []
    for line in new_content:
        if line.startswith('#EXTINF'):
            new_content_with_domain.append(line)
        elif line.endswith('.ts'):
            new_content_with_domain.append(f"{domain}/{line.strip()}")
        else:
            new_content_with_domain.append(line)
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path_parts = parsed_url.path.strip('/').split('/')
    name = '_'.join(path_parts)
    path = os.path.join(addon_data_dir, name)
    with open(path, 'w+') as f:
        for line in new_content_with_domain:
            f.write(f'{line}\n')
    limit_files_in_directory(addon_data_dir)
    return path
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm phim', searchimg, 'Tìm phim', 'search', is_folder=True)
        addDir('Phim mới', ICON, 'Phim mới', 'ds_apiionline', url = f'{uapi}/danh-sach/phim-moi-cap-nhat', p=1, is_folder=True)
        T = {'Thể loại': 'theloai',
        'Quốc gia': 'quocgia'}
        for b in T:
            addDir(b, ICON, b, T[b], is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'theloai':
        u = f'{uapi}/the-loai'
        resp = getlink(u, u, 1000)
        ri = resp.json()['categories']
        for k in ri:
            ten = unescape(k['name'])
            addDir(ten, ICON, ten, 'ds_apiionline', url = f"{uapi}/danh-sach?category={k['slug']}", p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'quocgia':
        u = f'{uapi}/quoc-gia'
        resp = getlink(u, u, 1000)
        ri = resp.json()['regions']
        for k in ri:
            ten = unescape(k['name'])
            addDir(ten, ICON, ten, 'ds_apiionline', url = f"{uapi}/danh-sach?country={k['slug']}", p=1, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'ds_apiionline':
        next_page = params['p']
        match = params['url']
        if int(next_page) == 1:
            n = match
        else:
            n = f'{match}&page={next_page}' if '?' in match else f'{match}?page={next_page}'
        resp = getlink(n, n, 1000)
        ri = resp.json()['items']
        for k in ri:
            ten = unescape(k['name'])
            anh = k['thumb_url'] if k['thumb_url'].startswith('http') else f"https://apii.online/image/{k['thumb_url']}"
            addDir(ten, anh, ten, 'id_apiionline', id = k['slug'], is_folder=True)
        if int(next_page) < resp.json()['pagination']['totalPages']:
            nextp = int(next_page) + 1
            addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', 'ds_apiionline', url = match, p=nextp, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            sr = quote_plus(query)
            match = f'{uapi}/danh-sach?search={sr}&page=1'
            resp = getlink(match, match, 1000)
            ri = resp.json()['items']
            for k in ri:
                ten = unescape(k['name'])
                anh = k['thumb_url'] if k['thumb_url'].startswith('http') else f"https://apii.online/image/{k['thumb_url']}"
                addDir(ten, anh, ten, 'id_apiionline', id = k['slug'], is_folder=True)
            if resp.json()['pagination']['totalPages'] > 1:
                addDir('Trang 2', nextimg, 'Trang 2', 'ds_apiionline', url = match, p=2, is_folder=True)
            endOfDirectory(HANDLE)
        else:
            quit()
    elif params['mode'] == 'id_apiionline':
        t = f'{uapi}/phim/{params["id"]}'
        resp = getlink(t, t, 1000)
        kq = resp.json()
        title = kq['movie']['name']
        mota = unescape(re.sub('<.*?>', '', kq['movie']['content']))
        anh = kq['movie']['thumb_url']
        for k1 in kq['episodes']:
            for k2 in k1['server_data']:
                if 'link_m3u8' in k2:
                    sv = k1['server_name']
                    tenm = f"[COLOR yellow]{sv}[/COLOR] Tập {k2['name']} - {title}"
                    if k2['link_m3u8']:
                        addDir(tenm, anh, mota, 'play_vn', url = k2['link_m3u8'], is_folder=False)
                    else:
                        addDir(tenm, anh, mota, 'play_nc', url = k2['link_embed'], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_nc':
        linkplay = re.sub(r'\s+', '%20', params['url'], flags=re.UNICODE).replace('embed.php', 'get.php').strip()
        ref = domain(linkplay)
        play_item = xbmcgui.ListItem(offscreen=True)
        hdr = f'Referer={ref}/&Origin={ref}&Keep-Alive=true&User-Agent={unquote(UA)}'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play_vn':
        linkplay = process_m3u8(params['url'])
        play_item = xbmcgui.ListItem(offscreen=True)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])