start ${var} end
