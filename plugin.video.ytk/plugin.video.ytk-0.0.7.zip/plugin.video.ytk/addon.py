from urllib.parse import urlencode, parse_qsl, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
import os, re, sys, urlquick, xbmcgui, yt_dlp
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
thaythe = {'\\"':'','\\u0026':'&'}
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/605.1.15 Edg/132.0.0.0'
def addDir(title, img, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def replace_all(dict, str):
    pattern = re.compile('|'.join(re.escape(key) for key in dict.keys()))
    return pattern.sub(lambda match: dict[match.group()], str)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'search', is_folder=True)
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, 'tim_yt', key = m, is_folder=True)
    endOfDirectory(HANDLE)
def timkiem(query):
    search_query = quote_plus(query)
    url = f'https://www.youtube.com/results?gl=VN&hl=vi&search_query={search_query}'
    resp = getlink(url, url, 7200)
    sre1 = re.compile(r'text":"(.*?)"}')
    sre2 = re.compile(r'videoId":"(.*?)"')
    sre3 = re.compile(r'"simpleText":"(.*?)"}')
    sre4 = re.compile(r'webCommandMetadata":{"url":"(.*?)"')
    sre5 = re.compile(r'"url":"(.*?)"')
    kq = replace_all(thaythe, resp.text)
    if 'videoRenderer' in kq:
        listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
        for k in listplay:
            tenvd = sre1.search(k)[1]
            idvd = sre2.search(k)[1]
            anhvd = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenvd, anhvd, 'play_yt', id=idvd, is_folder=False)
    elif 'playlistRenderer' in kq:
        listplay1 = re.findall(r'playlistRenderer(.*?)webPageType', kq)
        for k1 in listplay1:
            tenvd1 = sre3.search(k1)[1]
            idvd1 = sre4.search(k1)[1]
            anhvd1 = f'https://i.ytimg.com/vi/{idvd1}/sddefault.jpg'
            addDir(tenvd1, anhvd1, 'youtube_tatcavideo', id=f'{url}{idvd1}', is_folder=True)
    elif 'channelRenderer' in kq:
        listplay2 = re.findall(r'channelRenderer(.*?)webPageType', kq)
        for k2 in listplay2:
            tenvd2 = sre3.search(k2)[1]
            idvd2 = sre5.search(k2)[1]
            anhvd2 = f'https://i.ytimg.com/vi/{idvd2}/sddefault.jpg'
            addDir(tenvd2, anhvd2, 'youtube_kenh', id=f'{url}{idvd2}', is_folder=True)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm kiếm', searchimg, 'timkiem', is_folder=True)
        addDir('Trending', ICON, 'trending', is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên video ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query)
        else:
            find()
    elif params['mode'] =='timkiem':
        find()
    elif params['mode'] =='tim_yt':
        timkiem(params['key'])
    elif params['mode'] == 'trending':
        u = 'https://www.youtube.com/feed/trending?gl=VN&hl=vi'
        resp = getlink(u, u, 400)
        sre1 = re.compile(r'text":"(.*?)"}')
        sre2 = re.compile(r'videoId":"(.*?)"')
        kq = replace_all(thaythe, resp.text)
        listplay = re.findall(r'videoRenderer(.*?)accessibility', kq)
        for k in listplay:
            idvd = sre2.search(k)[1]
            tenm = sre1.search(k)[1]
            img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenm, img, 'play_yt', id=idvd, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'youtube_tatcavideo':
        url = params['id']
        resp = getlink(url, url, 1000)
        sre1 = re.compile(r'{"text":"(.*?)"}')
        sre2 = re.compile(r'"videoId":"(.*?)"')
        kq = replace_all(thaythe, resp.text)
        listplay = re.findall(r'richItemRenderer(.*?)navigationEndpoint', kq)
        for k in listplay:
            idvd = sre2.search(k)[1]
            tenm = sre1.search(k)[1]
            img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenm, img, 'play_yt', id=idvd, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'youtube_dslist':
        url = params['id']
        resp = getlink(url, url, 1000)
        sre1 = re.compile(r'{"text":"(.*?)"}')
        sre2 = re.compile(r'"videoId":"(.*?)"')
        kq = replace_all(thaythe, resp.text)
        listplay = re.findall(r'richItemRenderer(.*?)navigationEndpoint', kq)
        for k in listplay:
            idvd = sre2.search(k)[1]
            tenm = sre1.search(k)[1]
            img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenm, img, 'play_yt', id=idvd, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'youtube_kenh':
        addDir('Tất cả Video', ICON, 'youtube_tatcavideo', id=f'{url}/videos', is_folder=True)
        resp = getlink(url, url, 3600)
        sre1 = re.compile(r'text":"(.*?)"')
        sre2 = re.compile(r'"videoId":"(.*?)"')
        sre3 = re.compile(r'simpleText":"(.*?)"}')
        kq = replace_all(thaythe, resp.text)
        if 'channelVideoPlayerRenderer' in kq:
            listplay0 = re.findall(r'channelVideoPlayerRenderer(.*?)navigationEndpoint', kq)
            for k0 in listplay0:
                idvd0 = sre2.search(k0)[1]
                tenm = sre1.search(k0)[1]
                img = f'https://i.ytimg.com/vi/{idvd0}/sddefault.jpg'
                addDir(tenm, img, 'play_yt', id=idvd0, is_folder=False)
        listplay = re.findall(r'gridVideoRenderer(.*?)navigationEndpoint', kq)
        for k in listplay:
            idvd = sre2.search(k)[1]
            tenm = sre3.search(k)[1]
            img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenm, img, 'play_yt', id=idvd0, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_yt':
        play_item = xbmcgui.ListItem(offscreen=True)
        video_url = f"plugin://plugin.video.mytube/?action=play&video_Id={params['id']}"
        play_item.setPath(video_url)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])