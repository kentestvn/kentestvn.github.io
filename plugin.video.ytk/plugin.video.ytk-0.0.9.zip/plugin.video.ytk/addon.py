from urllib.parse import urlencode, parse_qsl, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from pickle import load, dump
from xbmcvfs import translatePath
import os, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
API_KEY = 'AIzaSyDMGvnC4vv_06oMy2C1Zd5MJyqaqz3aY5M'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
def addDir(title, img, mode, plot, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'search', 'Tìm kiếm', is_folder=True)
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, ICON, 'tim_yt', m, key = m, is_folder=True)
    endOfDirectory(HANDLE)
def timkiem(query):
    search_query = quote_plus(query)
    url = 'https://www.googleapis.com/youtube/v3/search'
    params = {
        'part': 'snippet,statistics',
        'q': search_query,
        'type': 'video',
        'regionCode': 'VN',
        'maxResults': 50,
        'key': API_KEY
    }
    response = urlquick.get(url, params=params, max_age=1000)
    data = response.json()
    for item in data['items']:
        tenm = item['snippet']['title']
        idvd = item['id']['videoId']
        img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
        description = item['snippet']['description']
        addDir(tenm, img, 'play_yt', description, id=idvd, is_folder=False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm kiếm', searchimg, 'timkiem', 'Tìm kiếm', is_folder=True)
        addDir('Trending', ICON, 'trending', 'Trending', is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên video ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query)
        else:
            find()
    elif params['mode'] =='timkiem':
        find()
    elif params['mode'] =='tim_yt':
        timkiem(params['key'])
    elif params['mode'] == 'trending':
        params = {
            'part': 'snippet,statistics',
            'chart': 'mostPopular',
            'regionCode': 'VN',
            'maxResults': 50,
            'key': API_KEY
        }
        response = urlquick.get(url, params=params, max_age=1000)
        data = response.json()
        for item in data['items']:
            tenm = item['snippet']['title']
            idvd = item['id']
            description = item['snippet']['description']
            img = f'https://i.ytimg.com/vi/{idvd}/sddefault.jpg'
            addDir(tenm, img, 'play_yt', description, id=idvd, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play_yt':
        play_item = xbmcgui.ListItem(offscreen=True)
        video_url = f"plugin://plugin.video.mytube/?action=play&videoId={params['id']}"
        play_item.setPath(video_url)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])