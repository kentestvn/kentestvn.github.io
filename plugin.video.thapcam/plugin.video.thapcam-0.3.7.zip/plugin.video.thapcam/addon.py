from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from functools import partial
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from http.client import HTTPSConnection
from requests import Session
from pickle import dumps, loads
from base64 import b64encode, b64decode
from collections import defaultdict
from datetime import datetime, timedelta
import re, sys, requests, xbmcgui, time
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/134.0.0.0 Mobile Safari/605.1.15 EdgA/134.0.0.0'
def addDir(title, logo, mode, is_folder=True, **kwargs):
    kwargs = {key: b64encode(dumps(value)).decode('utf-8') if isinstance(value, list) else value for key, value in kwargs.items()}
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref):
    r = requests.get(url, timeout=20, headers={'user-agent': UA, 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def urlfix(url):
    cleaned_location = '%20'.join(url.strip().split())
    return re.sub(r':(\/+)', r'://', cleaned_location)
def remove_html_tags(text):
    return re.sub(r'<[^>]*>', '', text)
def fu(url):
    return requests.get(url, headers={'user-agent': UA, 'referer': url.encode('utf-8')}, allow_redirects=True).url
def process_items(items):
    for a in items:
        tentran = a['name']
        idtran = a.get('share', {}).get('url')
        anhtran = a['image']['url']
        if a.get('sources', ''):
            org_metadata = a.get('org_metadata', {}).get('title', '')
            m = re.search(r"(\d{2}:\d{2})", org_metadata)
            thoigian = m.group(1) if m else ''
            blv = a.get('label') and a['label'].get('text', '') or ''
            for b in a['sources']:
                for c in b['contents']:
                    stream = sum(len(d.get('stream_links', [])) for d in c.get('streams') or [])
                    tenf1 = f'{thoigian} {tentran}' if thoigian else tentran
                    tenf = f'{tenf1} | {blv}' if blv else tenf1
                    if stream > 1:
                        addDir(tenf, anhtran, 'detail_thapcam', idtran = idtran, idm = anhtran, idt = tentran)
                    else:
                        for d in c['streams']:
                            for e in d['stream_links']:
                                if e['type'] != 'webview':
                                    if e.get('request_headers'):
                                        addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                                    else:
                                        addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
def play(link, ref=None):
    hdr = f'verifypeer=false&User-Agent={unquote(UA)}'
    linkplay = re.sub(r'\s+', '%20', link.strip(), flags=re.UNICODE)
    if ref:
        hdr += f'&Referer={ref}/'
    play_item = xbmcgui.ListItem(offscreen=True)
    if 'm3u8' in linkplay:
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
    else:
        linkplay = f'{linkplay}|{hdr}'
    play_item.setPath(linkplay)
    setResolvedUrl(HANDLE, True, listitem=play_item)
def play_nhadai(link):
    d = fu('https://daddylive.sx')
    link = f'{d}embed/stream-{link}.php'
    url_1 = re.search('iframe src="([^"]*)', getlink(link, d).text)[1]
    ref = referer(url_1)
    resp2 = getlink(url_1, d).text
    stream_id = re.search(r"fetch\('([^']*)", resp2)[1]
    url_2 = re.search(r'var channelKey = "([^"]*)', resp2)[1]
    m3u8 = re.search(r'(\/mono\.m3u8)',resp2)[1]
    key = re.search(r':"([^"]*)', getlink(f'{ref}{stream_id}{url_2}', ref).text)[1]
    play_item = xbmcgui.ListItem(offscreen=True)
    play_item.setPath(f'https://{key}.iosplayer.ru/{key}/{url_2}{m3u8}|verifypeer=false&Referer={ref}/&Origin={ref}&User-Agent={unquote(UA)}')
    setResolvedUrl(HANDLE, True, listitem=play_item)
def main():
    addDir('NHÀ ĐÀI', ICON, 'index_nhadai')
    addDir('TRẬN CẦU TÂM ĐIỂM', ICON, 'index_vebo')
    url = 'https://sport.xoilaczz.link/providers'
    data = getlink(url, url).json()['groups']
    for k in data:
        if re.search(r"'stream_links'\s*:\s*\[\s*{", str(k)):
            addDir(k['name'], ICON, 'list_thapcam', idk = k['remote_data']['url'])
    endOfDirectory(HANDLE)
def index_nhadai():
    d = fu('https://daddylive.sx')
    data = getlink(f'{d}schedule/schedule-generated.php', d).json()
    merged_data = defaultdict(list)
    key_order = []
    for schedule_key in data.keys():
        day, month = [m.groups() for m in re.finditer(r"(\d+)(?:st|nd|rd|th)? (\w+) \d{4}", schedule_key)][0]
        schedule_date = datetime(*time.strptime(f"{day} {month}", "%d %B")[:3])
        for key, shows in data[schedule_key].items():
            normalized_key = key.lower().strip()
            if normalized_key not in merged_data:
                key_order.append(normalized_key)
            merged_data[normalized_key].extend(shows)
    date_tracker = {}
    for key in key_order:
        tenkey = remove_html_tags(key).upper()
        if key not in date_tracker:
            date_tracker[key] = {
                "date": schedule_date,
                "previous_time": datetime(*(time.strptime("00:00", '%H:%M')[0:6]))
            }
        output = []
        for show in merged_data[key]:
            original_time = datetime(*(time.strptime(show['time'], '%H:%M')[0:6]))
            adjusted_time = original_time + timedelta(hours=7)
            if adjusted_time.time() < date_tracker[key]['previous_time'].time():
                date_tracker[key]['date'] += timedelta(days=1)
            date_tracker[key]['previous_time'] = adjusted_time
            channels = show['channels'] if isinstance(show['channels'], list) else []
            channel_ids = [(cid['channel_name'], cid['channel_id']) for cid in channels if isinstance(cid, dict) and 'channel_id' in cid]
            if channel_ids:
                output.append([
                    adjusted_time.strftime('%H:%M'),
                    date_tracker[key]['date'].strftime('%d/%m'),
                    show['event'],
                    channel_ids
                ])
        addDir(tenkey, ICON, 'list_nhadai', ids = b64encode(dumps(output)))
    endOfDirectory(HANDLE)
def list_nhadai(paramsids):
    ids = loads(b64decode(paramsids))
    for k in ids:
        tentran = f'{k[0]} {k[1]} {k[2]}'
        channel_ids = k[3]
        if len(channel_ids) > 1:
            addDir(tentran, ICON, 'detail_nhadai', ev = b64encode(dumps(channel_ids)), nameid = tentran)
        elif channel_ids:
            addDir(tentran, ICON, 'play_nhadai', link = channel_ids[0][1], is_folder=False)
    endOfDirectory(HANDLE)
def detail_nhadai(paramsev, nameid):
    ev = loads(b64decode(paramsev))
    for k in ev:
        channelname = k[0]
        channelid = k[1]
        ten = f'{nameid} | {channelname}'
        addDir(ten, ICON, 'play_nhadai', link = channelid, is_folder=False)
    endOfDirectory(HANDLE)
def index_vebo():
    url = 'https://api.vebo.xyz/api/match/featured/mt'
    resp = getlink(url, url).json()['data']
    for k in resp:
        time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M')
        blv = ' - '.join((h['name'] for h in k['commentators'] or []))
        tenv = f'{time} {k["name"]} | {blv}' if blv else f'{time} {k["name"]}'
        logotour = k['tournament']['logo']
        addDir(tenv, logotour, 'list_vebo', idk = k['id'], tentran = tenv, anhtran = logotour, slug = k['slug'])
    endOfDirectory(HANDLE)
def list_vebo(slug, idk, tenm, anhtran):
    urlvb = fu('https://vebo.tv')
    resp = getlink(f'{urlvb}truc-tiep/{slug}-{idk}', urlvb).text
    ref = referer(re.search(r"base_embed_url.*?'(.*?)'", resp)[1])
    kq = getlink(f'http://api.vebo.xyz/api/match/{idk}/meta', urlvb).json()['data']['play_urls']
    for k in kq:
        tenv = f"{tenm} | {k['name']}"
        addDir(tenv, anhtran, 'play', link = k['url'], ref = f'{ref}/', is_folder=False)
    endOfDirectory(HANDLE)
def list_thapcam(idp):
    data = getlink(idp, idp).json()
    all_data = []
    if 'groups' in data:
        g = data['groups']
        for k in g:
            process_items(k['channels'])
    else:
        process_items(data['channels'])
    endOfDirectory(HANDLE)
def detail_thapcam(idtran, anhtran, tentran):
    data = getlink(idtran, idtran).json()['channel']['sources']
    for b in data:
        for c in b['contents']:
            for d in c['streams']:
                blv = d['name']
                for e in d['stream_links']:
                    if e['type'] != 'webview':
                        tenf = f'{tentran} | {blv} | {e["name"]}'
                        if e.get('request_headers'):
                            addDir(tenf, anhtran, 'play', link = e['url'], ref = e['request_headers'][0]['value'], is_folder=False)
                        else:
                            addDir(tenf, anhtran, 'play', link = e['url'], is_folder=False)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action_map = {
        'index_nhadai': index_nhadai,
        'list_nhadai': partial(list_nhadai, params.get('ids')),
        'detail_nhadai': partial(detail_nhadai, params.get('ev'), params.get('nameid')),
        'index_vebo': index_vebo,
        'list_vebo': partial(list_vebo, params.get('slug'), params.get('idk'), params.get('tentran'), params.get('anhtran')),
        'list_thapcam': partial(list_thapcam, params.get('idk')),
        'detail_thapcam': partial(detail_thapcam, params.get('idtran'), params.get('idm'), params.get('idt')),
        'play': partial(play, params.get('link'), params.get('ref')),
        'play_nhadai': partial(play_nhadai, params.get('link')),
    }
    action_map.get(params.get('mode'), main)()
try:
    router(sys.argv[2][1:])
except:
    pass