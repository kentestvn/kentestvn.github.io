from urllib.parse import urlencode, parse_qsl, unquote, urlparse
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from datetime import datetime
from random import choice
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
apitc = 'https://q.thapcamn.xyz/api/match/'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON, 'fanart': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url):
    r = urlquick.get(url, timeout=30, max_age=-1, headers={'user-agent': UA,'referer': url.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        r = getlink(f'{apitc}featured/mt').json()['data']
        for k in r:
            time = datetime.fromtimestamp(int(k['timestamp'])/1000).strftime('%H:%M %d/%m')
            tg = f'[COLOR red]{time}[/COLOR]' if 'live' in k['match_status'] else time
            blv = ' - '.join((h['name'] for h in k["commentators"] or []))
            tenm = f'[COLOR yellow]{k["name"]}[/COLOR] {blv}' if blv else k['name']
            tenv = f'{tg} {tenm}'
            addDir(tenv, 'list_thapcam', idk = str(k['id']), slug = k['slug'], name=tenv)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_thapcam':
        dm = choice(getlink(f'{apitc}tc/live').json()['dm'])
        resp = getlink(f'https://{dm}/truc-tiep/{params["slug"]}-{params["idk"]}').text
        constid = re.search(r"const id.*?'(.*?)'", resp)[1]
        meta = re.search(r"meta/(.*?)`", resp)[1]
        ref = re.search(r"let base_embed_url.*?'(.*?)'", resp)[1]
        kq = getlink(f'{apitc}tc/{constid}/no/meta/{meta}').json()['data']
        kp = kq['play_urls']
        for k in kp:
            tenm = f'{k["name"]} {params["name"]}'
            addDir(tenm, 'play', id = k['url'], ref = ref, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={referer(params['ref'])}"
        if 'm3u8' in linkplay:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        else:
            linkplay = f'{linkplay}|{hdr}'
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])