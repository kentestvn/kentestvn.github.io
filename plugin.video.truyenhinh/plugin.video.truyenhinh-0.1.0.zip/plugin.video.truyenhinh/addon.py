from urllib.parse import urlencode, parse_qsl, unquote, urlparse, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from pickle import load, dump
import os, re, sys, xbmcgui, urlquick
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
PATH = Addon().getAddonInfo('path')
ICON = Addon().getAddonInfo('icon')
addon_id = Addon().getAddonInfo('id')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'OTT Navigator/1.7.2.2 (Linux; Android 15; Pixel 9 Pro Build/AP4A.241212) ExoPlayerLib/2.19.1'
UAM = 'Mozilla/5.0 (Linux; Android 15; Pixel 9 Pro Build/AP4A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/133.0.0.0 Mobile Safari/605.1.15 EdgA/133.0.0.0'
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), addon_id)
sre1 = re.compile(r'\n((http|https|udp|rtp|acestream):(.*?)\n)')
sre2 = re.compile(r'[,](?!.*[,])(.*)')
sre3 = re.compile(r'group-title="(.*?)"')
sre4 = re.compile(r'tvg-logo="(.*?)"')
sre5 = re.compile(r'http-user-agent=(.*?)\n')
sre6 = re.compile(r'http-referrer=(.*?)\n')
sre7 = re.compile(r'license_key=(.*?)\n')
def addDir(title, logo, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': logo, 'thumb': logo, 'poster': logo, 'fanart': logo})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'videos')
    if not is_folder:
        list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UAM,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def getlinkip(url, ref):
    r = urlquick.get(url, timeout=30, max_age=1000, headers={'user-agent': UA,'accept-encoding':'gzip','referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def referer(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}/'
def hlsvtv(idx):
    idp = re.sub(r'.*?vtv\.mediacdn\.vn/', 'https://cdn-videos.vtv.vn/', idx) if 'vtv.mediacdn.vn' in idx else f'https://cdn-videos.vtv.vn/{idx}'
    return f'{idp}/master.m3u8'
def domhtml(root, xpath, attribute=None, default=None):
    element = root.find(xpath)
    return default if element is None else element.get(attribute, '\n'.join(element.itertext()).strip())
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(filename):
    path = get_file_path(filename)
    if not os.path.exists(path):
        return None
    try:
        with open(path, 'rb') as f:
            return load(f)
    except:
        return None
def write_file(filename, data):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(filename)
    try:
        with open(path, 'wb') as f:
            dump(data, f)
    except:
        pass
    return path
def search_history_save(search_key):
    if not search_key:
        return
    history = read_file('historys.pkl') or []
    if search_key in history:
        history.remove(search_key)
    elif len(history) >= 20:
        history.pop()
    history.insert(0, search_key)
    write_file('historys.pkl', history)
def search_history_get():
    return read_file('historys.pkl') or []
def find():
    addDir('Tìm kiếm', searchimg, 'search')
    b = search_history_get()
    if b:
        for m in b:
            addDir(m, searchimg, 'timvtv', p=1, key = m)
    endOfDirectory(HANDLE)
def timkiem(query, nextpage):
    search_query = quote_plus(query)
    next_page = int(nextpage)
    u = f'https://vtv.vn/ajax-search-video.htm?PageIndex={next_page}&Keywords={search_query}'
    resp = getlink(u, u, 1000)
    root = resp.parse().iterfind('.//li[@class="lvdfli"]')
    for k in root:
        logo = domhtml(k, './/img', attribute='src')
        title = domhtml(k, './/a', attribute='title')
        idplay = domhtml(k, './/a', attribute='href')
        addDir(title, logo, 'playvtv', url=idplay, is_folder=False)
    trang = str(next_page + 1)
    addDir(f'Trang {trang}', nextimg, 'timvtv', p=trang, key=query)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        addDir('Tìm video', searchimg, 'timkiem')
        dulieu = {
            'Video mới': 'list_vtvvn',
            'Tin thể thao': 'thethao_vtvvn'}
        T = {'Truyền hình FPT1': 'https://raw.githubusercontent.com/ntd249/ntdiptv/main/fptudp',
            'Truyền hình FPT2': 'https://raw.githubusercontent.com/thanh51/repository.thanh51/master/ONETV.m3u',
            'CV Media': 'https://cvtv.xyz',
            'DakLakTV': 'https://raw.githubusercontent.com/luongtamlong/Dak-Lak-IPTV/main/daklakiptv.m3u',
            'VietNgaTV': 'https://raw.githubusercontent.com/phuhdtv/vietngatv/master/vietngatv.m3u',
            'VMTTV': 'https://dl.dropboxusercontent.com/s/7rj3pwr5b48ce3u/vmttv.txt?dl=0',
            'Khang IPTV': 'http://khanggtivi.xyz/iptv',
            'TV360': 'https://tth.vn/tv360',
            'Truyenhinhclick': 'https://tv.truyenhinh.click',
            'CaLemGTV': 'https://raw.githubusercontent.com/KevinNitroG/Entertainment/m3u/playlists/calemtv.m3u',
            'HaNoiIPTV': 'https://raw.githubusercontent.com/HaNoiIPTV/HaNoiIPTV.m3u/master/Danh%20s%C3%A1ch%20k%C3%AAnh/G%C3%B3i%20ch%C3%ADnh%20th%E1%BB%A9c/H%C3%A0%20N%E1%BB%99i%20IPTV.m3u',
            'AXT 4K Sport': 'https://raw.githubusercontent.com/MrToBun007/AXT/main/4K-UHD.m3u',
            'AlexDang 4K Sport': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
            '4K UHD TV': 'https://raw.githubusercontent.com/kgasaz/4kuhd/master/sports-channels-4k.m3u',
            'IPTV-ORG All': 'https://iptv-org.github.io/iptv/index.m3u',
            'IPTV-ORG Category': 'https://iptv-org.github.io/iptv/index.category.m3u',
            'IPTV-ORG Language': 'https://iptv-org.github.io/iptv/index.language.m3u',
            'IPTV-ORG Country': 'https://iptv-org.github.io/iptv/index.country.m3u',
            'IPTV-ORG Region': 'https://iptv-org.github.io/iptv/index.region.m3u'
            }
        for m in dulieu:
            addDir(m, ICON, dulieu[m], p=1)
        for k in T:
            addDir(k, ICON, 'list_iptv', id=T[k])
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Nhập từ khóa tìm kiếm ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            search_history_save(query)
            timkiem(query, 1)
        else:
            find()
    elif params['mode'] =='timkiem':
        find()
    elif params['mode'] =='timvtv':
        timkiem(params['key'], params['p'])
    elif params['mode'] == 'list_vtvvn':
        next_page = int(params["p"])
        url = f'https://vtv.vn/ajax-list-video-home-0/trang-{next_page}.htm'
        resp = getlink(url, url, 1000)
        root = resp.parse().iterfind('.//li[@class="item fade-out"]')
        for k in root:
            logo = domhtml(k, './/article//img', attribute='data-src')
            title = domhtml(k, './/article/a')
            play = hlsvtv(k.get('data-vfile'))
            addDir(title, logo, 'play', id=play, ref='https://vtv.vn/', is_folder=False)
        trang = str(next_page + 1)
        addDir(f'Trang {trang}', nextimg, 'list_vtvvn', p=trang)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'thethao_vtvvn':
        url = 'https://vtv.vn/the-thao.htm'
        resp = getlink(url, url, 1000)
        root = resp.parse().iterfind('.//ul[@class="listnbbhtl swiper-wrapper clearfix"]//li[@class="swiper-slide"]')
        for k in root:
            logo = domhtml(k, './/img', attribute='data-src')
            title = domhtml(k, './/h3')
            play = hlsvtv(k.get('data-video'))
            addDir(title, logo, 'play', id=play, ref='https://vtv.vn/', is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_iptv':
        url = params['id']
        addDir('TẤT CẢ CÁC KÊNH', ICON, 'little_iptv', id=url)
        texturl = getlinkip(url, url).text
        group = re.findall(r'group-title="(.*?)"', texturl)
        ld = list(dict.fromkeys(group))
        um = []
        um = [k for tk in ld for k in (tk.split(';') if ';' in tk else [tk]) if k != '' and k not in um]
        for p in um:
            addDir(p, ICON, 'info_iptv', id=url, tk=p)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'info_iptv':
        url = params['id']
        tk = params['tk']
        texturl = getlinkip(url, url).text
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s7 = sre7.search(kq)
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else None
            if s1 and s2 and any(((not s7 and f'group-title="{tk}"' in kq and ';' not in kq), (tk in kq and ';' in kq))):
                addDir(s2[1], logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'little_iptv':
        url = params['id']
        texturl = getlinkip(url, url).text
        ketqua = re.sub(r'(#EXTM3U|#[^EX|^KODI])(.*)', '', texturl).split('#EXTINF')
        for kq in ketqua:
            s1 = sre1.search(kq)
            s2 = sre2.search(kq)
            s3 = sre3.search(kq)
            s4 = sre4.search(kq)
            s5 = sre5.search(kq)
            s6 = sre6.search(kq)
            s7 = sre7.search(kq)
            nhomkenh = s3[1] if s3 else 'TỔNG HỢP'
            logo = s4[1] if s4 else ICON
            user = s5[1] if s5 else UA
            ref = s6[1] if s6 else None
            if s1 and s2 and not s7:
                tenm = f'{s2[1]} - {nhomkenh}'
                addDir(tenm, logo, 'play', id=s1[1], ref=ref, user=user, is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'playvtv':
        url = f"https://vtv.vn/{params['url']}" if params['url'].startswith('/') else params['url']
        resp = getlink(url, url, 1000)
        vfileplay = re.search(r"vid:.*?'(.*?)'", resp.text)[1]
        vfile = hlsvtv(vfileplay)
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', vfile.strip(), flags=re.UNICODE)
        hdr = f'verifypeer=false&User-Agent={UA}&Referer=https://vtv.vn/'
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    elif params['mode'] == 'play':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['id'].strip(), flags=re.UNICODE)
        user = unquote(params.get('user', UA))
        if 'm3u8' in linkplay:
            hdr = f'verifypeer=false&User-Agent={user}'
            if params.get('ref'):
                hdr += f'&Referer={referer(params["ref"])}'
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
            play_item.setPath(linkplay)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])