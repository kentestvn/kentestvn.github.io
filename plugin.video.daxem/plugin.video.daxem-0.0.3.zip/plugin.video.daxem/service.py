from xbmc import getInfoLabel, Player, Monitor
from xbmcvfs import translatePath
from time import sleep
from json import loads, dumps
from collections import OrderedDict
from urllib.parse import unquote
from xbmcaddon import Addon
import os
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), Addon().getAddonInfo('id'))
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        path = get_file_path(name)
        f = open(path, mode=read_mode)
        content = f.read()
        f.close()
    except:
        pass
    return content
def write_file(name, content, binary=False):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(name)
    try:
        write_mode = 'wb+' if binary else 'w+'
        f = open(path, mode=write_mode)
        f.write(content)
        f.close()
    except:
        pass
    return path
def save_last_watch(data):
    if not data:
        return
    content = read_file('daxem.json')
    content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
    cache_id, query = data
    if query not in content:
        content.update({cache_id: query})
        content.move_to_end(cache_id, last=False)
        while len(content) > 50:
            content.popitem(last=True)
        write_file('daxem.json', dumps(content))
    else:
        return
def decode_url(encoded_url):
    decoded_url = encoded_url
    while True:
        new_decoded = unquote(decoded_url)
        if new_decoded == decoded_url:
            break
        decoded_url = new_decoded
    return decoded_url
def simplify_url(url):
    decoded_url = decode_url(url)
    simplified_url = decoded_url.split('plugin://')[-1]
    return f'plugin://{simplified_url}'
def on_playback_started():
    path = getInfoLabel('Player.FilenameAndPath')
    title = getInfoLabel('ListItem.Title')
    if not path or not title:
        return
    addon_name = Addon(path.split('/')[2]).getAddonInfo('name')
    save_last_watch((f"[{addon_name}] {title}", simplify_url(path)))
player = Player()
while not Monitor().abortRequested():
    if player.isPlaying():
        on_playback_started()
    sleep(1)