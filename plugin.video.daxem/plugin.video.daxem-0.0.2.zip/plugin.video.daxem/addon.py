from urllib.parse import urlencode, parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from xbmcvfs import translatePath
from xbmcgui import ListItem
from json import loads
import sys, os
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        path = get_file_path(name)
        f = open(path, mode=read_mode)
        content = f.read()
        f.close()
    except:
        pass
    return content
def get_last_watch():
    content = read_file('daxem.json')
    content = loads(content) if content else {}
    return content
def addDir(title=None, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": "play", **kwargs})}'
    list_item = ListItem(title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    list_item.setInfo('video', infoLabels={'title': title, 'plot': title})
    setContent(HANDLE, 'episodes')
    list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, False)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        data= get_last_watch()
        if data:
            for m in data:
                addDir(m, link = data[m])
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        play_item = ListItem(offscreen=True)
        play_item.setPath(params['link'])
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])