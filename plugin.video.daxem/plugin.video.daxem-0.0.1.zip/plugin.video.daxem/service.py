import xbmc, xbmcvfs, os, time, json
from collections import OrderedDict
addon_data_dir = os.path.join(xbmcvfs.translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
dx = 'daxem.json'

def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        path = get_file_path(name)
        f = open(path, mode=read_mode)
        content = f.read()
        f.close()
    except:
        pass
    return content
def write_file(name, content, binary=False):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(name)
    try:
        write_mode = 'wb+' if binary else 'w+'
        f = open(path, mode=write_mode)
        f.write(content)
        f.close()
    except:
        pass
    return path
def save_last_watch(data):
    if not data:
        return
    content = read_file(dx)
    content = json.loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
    cache_id, query = data
    content.update({cache_id: query})
    content.move_to_end(cache_id, last=False)
    while len(content) > 50:
        content.popitem(last=True)
    write_file(dx, json.dumps(content))
def on_playback_started():
    path = xbmc.getInfoLabel('Player.FilenameAndPath')
    title = xbmc.getInfoLabel('ListItem.Title')
    if not path or not title:
        return
    save_last_watch((title, path))

player = xbmc.Player()
while not xbmc.Monitor().abortRequested():
    if player.isPlaying():
        on_playback_started()
    time.sleep(1)