from xbmc import getInfoLabel, Player, Monitor
from xbmcvfs import translatePath
from time import sleep
from json import loads, dumps
from collections import OrderedDict
import os
addon_data_dir = os.path.join(translatePath('special://userdata/addon_data'), 'plugin.video.daxem')
def get_file_path(filename):
    return os.path.join(addon_data_dir, filename)
def read_file(name, binary=False):
    content = None
    read_mode = 'rb' if binary else 'r'
    try:
        with open(get_file_path(name), mode=read_mode) as f:
            content = f.read()
    except:
        pass
    return content
def write_file(name, content, binary=False):
    if not os.path.exists(addon_data_dir):
        os.makedirs(addon_data_dir)
    path = get_file_path(name)
    try:
        write_mode = 'wb+' if binary else 'w+'
        with open(path, mode=write_mode) as f:
            f.write(content)
    except:
        pass
    return path
def save_last_watch(data):
    if not data:
        return
    content = read_file('daxem.json')
    content = loads(content, object_pairs_hook=OrderedDict) if content else OrderedDict()
    cache_id, query = data
    content.update({cache_id: query})
    content.move_to_end(cache_id, last=False)
    while len(content) > 50:
        content.popitem(last=True)
    write_file('daxem.json', dumps(content))
def on_playback_started():
    path = getInfoLabel('Player.FilenameAndPath')
    title = getInfoLabel('Player.Title')
    if not path.startswith('plugin://') or not title:
        return
    save_last_watch((title, path))
player = Player()
while not Monitor().abortRequested():
    if player.isPlaying():
        on_playback_started()
    sleep(1)