from urllib.parse import urlencode, parse_qsl, unquote, quote_plus
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from html import unescape
import re, sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_name = Addon().getAddonInfo('name')
ICON = Addon().getAddonInfo('icon')
PATH = Addon().getAddonInfo('path')
RESOURCES = PATH + '/media/'
searchimg = RESOURCES +'search.png'
nextimg = RESOURCES + 'next.png'
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP2A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/129.0.0.0 Mobile Safari/605.1.15 EdgA/129.0.0.0'
avdb = 'https://avdbapi.com'
def addDir(title, img, plot, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': img, 'thumb': img, 'poster': img})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(plot)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def main():
    addDir('Tìm phim', searchimg, 'Tìm phim', 'search', is_folder=True)
    addDir('Phim mới', ICON, 'Phim mới', 'ds_avdb', url = f'{avdb}/api.php/provide/vod/?ac=detail', p=1, is_folder=True)
    endOfDirectory(HANDLE)
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        main()
    elif params['mode'] == 'ds_avdb':
        next_page = params['p']
        match = params['url']
        n = f'{match}&pg={next_page}' if '?' in match else f'{match}?pg={next_page}'
        resp = getlink(n, n, 1000)
        data = resp.json()['list']
        for item in data:
            for episode in [item['episodes']]:
                for data_key in episode['server_data']:
                    if 'link_embed' in episode['server_data'][data_key]:
                        server_name = episode['server_name']
                        slug = episode['server_data'][data_key]['slug']
                        name = unescape(item['name'])
                        poster_url = item['poster_url']
                        description = unescape(item['description'])
                        link_embed = episode['server_data'][data_key]['link_embed']
                        linkplay = link_embed.split('?s=')[1]
                        ref = link_embed.split('?s=')[0]
                        tenphim = f"[COLOR yellow]{slug}[/COLOR] [COLOR red]{server_name}[/COLOR] {name}"
                        addDir(tenphim, poster_url, description, 'play_vn', linkplay = linkplay, ref = ref, is_folder=False)
        if int(next_page) < resp.json()['pagecount']:
            nextp = int(next_page) + 1
            addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', 'ds_avdb', url = match, p=nextp, is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] =='search':
        query = xbmcgui.Dialog().input(u'Tìm: tên phim ...', type=xbmcgui.INPUT_ALPHANUM)
        if query:
            next_page = 1
            sr = quote_plus(query)
            match = f'{avdb}/api.php/provide/vod?ac=detail&wd={sr}'
            n = f'{match}&pg={next_page}' if '?' in match else f'{match}?pg={next_page}'
            resp = getlink(n, n, 1000)
            data = resp.json()['list']
            for item in data:
                for episode in [item['episodes']]:
                    for data_key in episode['server_data']:
                        if 'link_embed' in episode['server_data'][data_key]:
                            server_name = episode['server_name']
                            slug = episode['server_data'][data_key]['slug']
                            name = unescape(item['name'])
                            poster_url = item['poster_url']
                            description = unescape(item['description'])
                            link_embed = episode['server_data'][data_key]['link_embed']
                            linkplay = link_embed.split('?s=')[1]
                            ref = link_embed.split('?s=')[0]
                            tenphim = f"[COLOR yellow]{slug}[/COLOR] [COLOR red]{server_name}[/COLOR] {name}"
                            addDir(tenphim, poster_url, description, 'play_vn', linkplay = linkplay, ref = ref, is_folder=False)
            if int(next_page) < resp.json()['pagecount']:
                nextp = int(next_page) + 1
                addDir(f'Trang {nextp}', nextimg, f'Trang {nextp}', 'ds_avdb', url = match, p=nextp, is_folder=True)
            endOfDirectory(HANDLE)
        else:
            main()
    elif params['mode'] == 'play_vn':
        play_item = xbmcgui.ListItem(offscreen=True)
        linkplay = re.sub(r'\s+', '%20', params['linkplay'].strip(), flags=re.UNICODE)
        hdr = f"Referer={params['ref']}/&Origin={params['ref']}&Keep-Alive=true&User-Agent={unquote(UA)}"
        play_item.setProperty('inputstream', 'inputstream.adaptive')
        play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
        play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
    else:
        raise ValueError(f'Tham số {paramstring} không hợp lệ!')
if __name__ == '__main__':
    try:
        router(sys.argv[2][1:])
    except:
        xbmcgui.Dialog().notification(addon_name, 'Không lấy được dữ liệu', ICON)