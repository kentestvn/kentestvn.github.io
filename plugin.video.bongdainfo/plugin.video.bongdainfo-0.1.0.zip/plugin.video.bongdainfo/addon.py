from urllib.parse import urlencode, parse_qsl, urlparse, unquote
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
from concurrent.futures import ThreadPoolExecutor
from calendar import timegm
from time import strftime, strptime, mktime, gmtime, localtime
import re, sys, os, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
addon_id = Addon().getAddonInfo('id')
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 9 Pro Build/AP2A.240805.005) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/605.1.15 EdgA/132.0.0.0'
def addDir(title, mode, is_folder=True, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    if not is_folder:
        setContent(HANDLE, 'episodes')
        list_item.setProperty('IsPlayable', 'true')
    else:
        setContent(HANDLE, 'tvshows')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=30, max_age=luu, headers={'user-agent': UA,'referer': ref.encode('utf-8')}, verify=False)
    r.encoding = 'utf-8'
    return r
def domain(url):
    parsed_url = urlparse(url.strip())
    return f'{parsed_url.scheme}://{parsed_url.netloc}'
def ct(initial_time):
    struct_time = strptime(initial_time, '%Y-%m-%d %H:%M:%S')
    timestamp = mktime(struct_time) + (7 * 3600)
    new_time = strftime('%H:%M %d/%m', localtime(timestamp))
    return new_time
def get_i():
    ts = timegm(gmtime())
    return getlink(f'https://embed.plcdn.xyz/gf/data/bf_vn_nt.js?{ts}', 'https://embed.plcdn.xyz/', 400)
def get_l():
    return getlink(f'https://tvlive.vbfast.xyz/tvlive_vn_fb.txt', 'https://embed.plcdn.xyz/', 400)
def inf():
    with ThreadPoolExecutor(2) as ex:
        f1 = ex.submit(get_i)
        f2 = ex.submit(get_l)
    return (f1.result(),f2.result())
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        resp1, resp2 = inf()
        ids = re.findall(r'[$|!](\d+)', resp2.text)
        r1 = resp1.text
        for k in ids:
            try:
                m = re.search(rf"{k}.*?'(.*?)'.*?'(.*?)'.*?'(.*?)'", r1)
                ten = f'{ct(m[3])}: {m[1]} vs {m[2]}'
                addDir(ten, 'list_91phut', k = k, t = ten, is_folder=True)
            except:
                pass
        endOfDirectory(HANDLE)
    elif params['mode'] == 'list_91phut':
        r = get_l()
        k = params["k"]
        if k in r.text:
            match = re.search(rf'{k}(.*?)\!', r.text)
            urls = re.findall(r'(https://.*?)\^', match[1])
            for dem, k in enumerate(urls, start=1):
                ten = f'Sv{dem} - {params["t"]}'
                addDir(ten, 'sv_91phut', k = k, t=params["t"], is_folder=True)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'sv_91phut':
        url = params["k"]
        name = params["t"]
        resp = getlink(url, url, 400)
        if 'link-video' in resp.text:
            soup = resp.parse("div", attrs={"class": "link-video"})
            for k in soup.iterfind('.//a'):
                ten = ''.join(k.itertext()).strip()
                ep = k.get('href')
                addDir(f'{ten} - {name}', 'ifr_bongda', ep = ep, t=params["t"], is_folder=False)
        elif 'tv_links' in resp.text:
            soup = resp.parse("div", attrs={"id": "tv_links"})
            for k in soup.iterfind('.//a'):
                ten = ''.join(k.itertext()).strip()
                ep = k.get('href')
                addDir(f'{ten} - {name}', 'ifr_bongda', ep = ep, t=params["t"], is_folder=False)
        else:
            addDir(name, 'ifr_bongda', ep = url, t=params["t"], is_folder=False)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'ifr_bongda':
        play_item = xbmcgui.ListItem(offscreen=True)
        url = params["ep"]
        resp = getlink(url, url, -1)
        frame_element = resp.parse("iframe", attrs={"allowfullscreen": "true"})
        ifr = frame_element.get('src') if frame_element is not None else ''
        ifr = ifr if 'http' in ifr else f'{domain(url)}{ifr}'
        ref = domain(ifr)
        r = getlink(ifr, url, -1)
        sre = re.compile(r'(https?://[^\s"]+\.m3u8[^"\']*)')
        linkstream = sre.search(r.text)[1]
        linkplay = re.sub(r'\s+', '%20', linkstream.strip(), flags=re.UNICODE)
        hdr = f"verifypeer=false&User-Agent={unquote(UA)}&Referer={ref}/"
        if any((re.search(r':(?!/)', linkplay), ('?' in linkplay))):
            linkplay += f'|{hdr}'
        else:
            play_item.setProperty('inputstream', 'inputstream.adaptive')
            play_item.setProperty('inputstream.adaptive.stream_headers', hdr)
            play_item.setProperty('inputstream.adaptive.manifest_headers', hdr)
        play_item.setPath(linkplay)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])