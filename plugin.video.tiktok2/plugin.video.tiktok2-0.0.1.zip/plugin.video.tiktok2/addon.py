from urllib.parse import urlencode, parse_qsl
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from xbmcaddon import Addon
import sys, urlquick, xbmcgui
addon_url = sys.argv[0]
HANDLE = int(sys.argv[1])
ICON = Addon().getAddonInfo('icon')
UA = 'Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro Build/AP1A.261212) AppleWebKit/605.1.15 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/605.1.15 EdgA/131.0.0.0'
def addDir(title, mode, is_folder=False, **kwargs):
    dir_url = f'{addon_url}?{urlencode({"mode": mode, **kwargs})}'
    list_item = xbmcgui.ListItem(label=title)
    list_item.setArt({'icon': ICON, 'thumb': ICON, 'poster': ICON})
    info_tag = list_item.getVideoInfoTag()
    info_tag.setTitle(title)
    info_tag.setPlot(title)
    setContent(HANDLE, 'episodes')
    list_item.setProperty('IsPlayable', 'true')
    addDirectoryItem(HANDLE, dir_url, list_item, is_folder)
def getlink(url, ref, luu):
    r = urlquick.get(url, timeout=20, max_age=luu, headers={'user-agent': UA, 'cookie': 'ttwid=1%7C1CvwVKEkhe_Jnp9-VrcHKqW9ukVpIOgbHw2dv30LPX4%7C1715575355%7C1fe4cefa796c2b9517ac7fd7fcf02486d1e56bcb35ff44dd4705d0f599552850; tt_chain_token=/jKvFgpGYkelaULvQIf7ag==; tiktok_webapp_theme_auto_dark_ab=1; tiktok_webapp_theme_source=auto; delay_guest_mode_vid=8; odin_tt=3e5a35aafa01e783b4d70c83e3ee302caac67d2e4544af454b29999852b21cf0c4fffc72440ffb0e883756df972ddc843aeffc6be75b22c8c24ba56e84913bd3a0f8863593b458e8cff5a17fca2aea58; tiktok_webapp_theme=dark; tt_csrf_token=qRz8JYZd-I-j2mFTRKPOIvOn0ygVQPjDz8Cc; ak_bmsc=AE8D98E380297E68201398BE574041E9~000000000000000000000000000000~YAAQzr4vF7a4JbWSAQAAja/EtxlJQN8IfXbHSWW2Tk1lUATLxrk1i83c/pb2mEUxFJCNXvEVaZYEtrr7k2MARLIVZF/YEhb4B7FQlz9pFyOK4qOi3wOWBbClRLRGctqldJW9t479duhkb4OPkm9FTdJHVYiq2tOrNUaYT20feLnf7SrSPEupGT9TflXtmaNFZ0cbolAUjKpv6aQkMTdXOiqQBaqDOh/+yh/JPJ1a+FulFd8vvuZtL8XFewzwk669HJNTz7QUFHQidh6my/Noup3MR+9cbPe3g+nIPLoD/c9uKFZEYbrNq5W+7WPO4I7KizlbbDHTJNSAtTz1ah7iCReTLHz75+KfcCPx1FGnAwJNqOgojGQIRfYmp9We+PeXrDPzmU7Ufu+0kDo=; bm_sv=2F42EA3BDA8CAF543AA7389E80898384~YAAQHPN0aIX7LbSSAQAAkX/Gtxlt9CkZi5cWGu5UMqFB5ok/7QZmdEFWhMOXLrHGUCb4rchk/EeWEGDBMgJUm94Vj7pDN27h4WLUxYYI7NLqu4OV1nuX1xgceWig+/aPTSaUodup84M+jxjEAXBzlH1onOamLUluGst2Yav2ErP3YlTcM1OesNhTLGxevZT4ec2gMBQRHjKkGKFSOOIxMrnXWcwvuMuxOoGm+n40mrGnIqK2T0IXIL877rtGtuxV~1; perf_feed_cache={%22expireTimestamp%22:1729832400000%2C%22itemIds%22:[%227423705837736152327%22%2C%227423660471322021128%22%2C%227426187433210809618%22]}; msToken=-K0nOBH6HtzjqpniGM-u_TvmrgsBzdP7AYhxgIrKFmXDAey8Z5Q3bVSVyh1PAJPL20OddMACzzWNSZRdZ0lRCVmX-lJLfA2tx06PBpON1AhjN8KkZIhn7zfTcQcbfEH-gmMiwie-hKc_1ClUxcjmfDw=; msToken=-K0nOBH6HtzjqpniGM-u_TvmrgsBzdP7AYhxgIrKFmXDAey8Z5Q3bVSVyh1PAJPL20OddMACzzWNSZRdZ0lRCVmX-lJLfA2tx06PBpON1AhjN8KkZIhn7zfTcQcbfEH-gmMiwie-hKc_1ClUxcjmfDw=', 'referer': ref.encode('utf-8')})
    r.encoding = 'utf-8'
    return r
def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if not params:
        u = 'https://www.tiktok.com/api/explore/item_list/?WebIdLastTime=0&aid=1988&app_language=vi-VN&app_name=tiktok_web&browser_language=vi&browser_name=Mozilla&browser_online=true&browser_platform=Win32&browser_version=5.0%20%28Windows%20NT%2010.0%3B%20Win64%3B%20x64%29%20AppleWebKit%2F537.36%20%28KHTML%2C%20like%20Gecko%29%20Chrome%2F130.0.0.0%20Safari%2F537.36%20Edg%2F130.0.0.0&categoryType=120&channel=tiktok_web&clientABVersions=70508271%2C72287505%2C72422413%2C72619046%2C72700840%2C72702738%2C72767631%2C72798189%2C72820429%2C72820457%2C72820482%2C72836226%2C72848407%2C72864712%2C72874284%2C72874368%2C72879957%2C72886415%2C72907371%2C72917256%2C72935609%2C70405643%2C71057832%2C71200802%2C72258247&cookie_enabled=true&count=16&data_collection_enabled=false&device_id=7368339944547370513&device_platform=web_pc&focus_state=true&from_page=&history_len=15&is_fullscreen=false&is_page_visible=true&language=vi&odinId=7368338539190977553&os=windows&priority_region=&referer=https%3A%2F%2Fwww.tiktok.com%2Fdiscover%2Ftik-tok-trending&region=VN&root_referer=https%3A%2F%2Fwww.tiktok.com%2Fdiscover%2Ftik-tok-trending&screen_height=1024&screen_width=1280&tz_name=Etc%2FGMT-7&user_is_login=false&webcast_language=vi-VN'
        r = getlink(u, u, 60)
        kq = r.json()['itemList']
        for k in kq:
            tenm = k['desc']
            username = k['author']['uniqueId']
            idplay = k['id']
            play = f'https://tikwm.com/api/?url=https://www.tiktok.com/@{username}/video/{idplay}'
            addDir(tenm, 'play', id=play)
        endOfDirectory(HANDLE)
    elif params['mode'] == 'play':
        u = params['id']
        r = getlink(u, u, 60)
        play = r.json()['data']['play']
        play_item = xbmcgui.ListItem(offscreen=True)
        play_item.setPath(play)
        setResolvedUrl(HANDLE, True, listitem=play_item)
if __name__ == '__main__':
    router(sys.argv[2][1:])